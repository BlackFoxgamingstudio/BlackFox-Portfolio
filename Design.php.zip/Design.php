<?php 
  $this->load->view('partials/head');
?>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Dreamlancer 0-100 Design</title>
  
  <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
 <script src="http://codeorigin.jquery.com/jquery-1.10.2.min.js" type="text/javascript"></script>
  <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="http://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.min.css">
<!-- jQuery library -->
<script type="text/javascript" src="/assets/js/jquery-1.10.2.js"></script>
<script type="text/javascript" src="/assets/js/jquery-ui-1.10.4.custom.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	<link href='https://fonts.googleapis.com/css?family=Playfair+Display:700,900|Fira+Sans:400,400italic' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" href="/assets/css/style.css"> <!-- Resource style -->

 <script src="/assets/js/script2.js"></script>
 
<!--Latest compiled JavaScript -->
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
 <!-- Latest compiled and minified CSS -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js" type="text/javascript"></script>

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<!-- Latest compiled JavaScript -->
 <link href='https://fonts.googleapis.com/css?family=Lato' rel='stylesheet' >
      <link href='/assets/stylesheets/jquery.gridly.css' rel='stylesheet' >
      
      <script src='/assets/javascripts/jquery.js'></script>
     
      <script src='/assets/javascripts/sample.js' ></script>
      <script src='/assets/javascripts/rainbow.js' ></script>
      <script>
        
      </script>
  
 
    <link href='https://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
      <link href='/assets/stylesheets/jquery.gridly.css' rel='stylesheet' type='text/css'>
     
      <script src='/assets/javascripts/jquery.js' type='text/javascript'></script>
      <script src='/assets/javascripts/jquery.gridly.js' type='text/javascript'></script>
      <script src='/assets/javascripts/sample.js' type='text/javascript'></script>
      <script src='/assets/javascripts/rainbow.js' type='text/javascript'></script>
 
<script>
  $('.gridly').gridly({
    base: 60, // px 
    gutter: 20, // px
    columns: 12
  });
  $('.brick').ondblclick(function() {
    $this = $(this);

    // toggle the size of the brick using css class
    $this.toggleClass('large').toggleClass('small');

    // this is set to ensure the layout is carried out on the final size of the brick
    size = $this.hasClass('small') ? 140 : 300;
    $this.data('width', size);
    $this.data('height', size);

    return $('.gridly').gridly('layout');
  });

</script>

 <script>
    
    //read input url
   function readURL(input) {

    if (input.files && input.files[0]) {
        var reader = new FileReader();

// at location
        reader.onload = function (e) {
            $('#blah1').attr('src', e.target.result);
            
        }

        reader.readAsDataURL(input.files['0']);
    }
    
}

$("#imgInp").change(function(){
    readURL(this);
});
</script>

</script>
<STYLE>
@import url(http://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic);
html {
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: inherit;
}

  .gridly {
    position: relative;
    width: 960px;
  }
  .brick {
    overflow: hidden;
  }
  .brick img {
    padding: 10px;
  }
  .brick div {
    padding: 0 10px 0 10px;
  }
  .brick.small {
    width: 140px;
    height: 140px;
    background-color: gray;
  }
  .brick.large {
    width: 300px;
    height: 300px;
    background-color: #B0B0B0;
  }

@media screen and (max-width: 500px) {
  .steps-timeline {
    border-left: 2px solid #3498DB;
    margin-left: 25px;
  }
}
@media screen and (min-width: 500px) {
  .steps-timeline {
    border-top: 2px solid #3498DB;
    padding-top: 20px;
    margin-top: 40px;
    margin-left: 16.65%;
    margin-right: 16.65%;
  }
}
.steps-timeline:after {
  content: "";
  display: table;
  clear: both;
}

.steps-one,
.steps-two,
.steps-three {
  outline: 1px dashed rgba(0, 128, 0, 0);
}
@media screen and (max-width: 500px) {
  .steps-one,
  .steps-two,
  .steps-three {
    margin-left: -25px;
  }
}
@media screen and (min-width: 500px) {
  .steps-one,
  .steps-two,
  .steps-three {
    float: left;
    width: 33%;
    margin-top: -50px;
  }
}

@media screen and (max-width: 500px) {
  .steps-one,
  .steps-two {
    padding-bottom: 40px;
  }
}

@media screen and (min-width: 500px) {
  .steps-one {
    margin-left: -16.65%;
    margin-right: 16.65%;
  }
}

@media screen and (max-width: 500px) {
  .steps-three {
    margin-bottom: -100%;
  }
}
@media screen and (min-width: 500px) {
  .steps-three {
    margin-left: 16.65%;
    margin-right: -16.65%;
  }
}

.steps-img {
  display: block;
  margin: auto;
  width: 50px;
  height: 50px;
  border-radius: 50%;
}
@media screen and (max-width: 500px) {
  .steps-img {
    float: left;
    margin-right: 20px;
  }
}

.steps-name,
.steps-description {
  margin: 0;
}

@media screen and (min-width: 500px) {
  .steps-name {
    text-align: center;
  }
}

.steps-description {
  overflow: hidden;
}
@media screen and (min-width: 500px) {
  .steps-description {
    text-align: center;
  }
}


</STYLE>



 
</head>

<?php 
  $this->load->view('partials/navbar');
  $this->load->view('partials/messages');
  
?>
<?php     
  if($this->session->userdata('name'))
  {
?>          
   <center> <div class="container">
      <div class="row">
        <div class="col-lg-12">

          <center><h2>Welcome <?= $this->session->userdata('name'); ?></h2></center>
          <center><h1> Your Storyboard begins here!</h1></center>
        </div>
      </div>
    </div></center>
<?php     }
?>

<div id="myCarousel" class="carousel slide" data-ride="carousel">
      <!-- Indicators -->
      <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1" class=""></li>
        <li data-target="#myCarousel" data-slide-to="2" class=""></li>
      </ol>
      <div class="carousel-inner" role="listbox">
        <div class="item">
          <img class="first-slide" src="http://gdriv.es/heroimg1/
Untitled-2.jpg" alt="First slide">
        <div class="container">
            <div class="carousel-caption">
             
              <a class="btn btn-lg btn-primary" href="#" role="button">Learn more</a>
            </div>
          </div>
        </div>
        <div class="item">
          <img class="second-slide" src="http://gdriv.es/heroimg1/
Untitled-3.png" alt="Second slide">
          <div class="container">
            <div class="carousel-caption">
             
              <a class="btn btn-lg btn-primary" href="#" role="button">Learn more</a>
            </div>
          </div>
        </div>
        <div class="item active">
          <img class="third-slide" src="http://gdriv.es/heroimg1/

bannerADDSTest1.png" alt="Third slide">
          <div class="container">
            <div class="carousel-caption">
             
              <a class="btn btn-lg btn-primary" href="#" role="button">Learn more</a>
            </div>
          </div></div>
      </div>
      <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div>



<div class"col-lg-12 btn btn-info">
<!-- STEPS -->
<section id="Steps" class="steps-section">

  <h2 class="steps-header">
      Responsive Semantic Timeline
    </h2>

  <div class="steps-timeline">

    <div class="steps-one">
      <img class="steps-img" src="http://placehold.it/50/3498DB/FFFFFF" alt="" />
      <h3 class="steps-name">
          Design
        </h3>
      <p class="steps-description">
        <div class="container"><div class="row"><div class="col-md-6">
<form role="form" style="margin-left: 85px">
 
 <div class="checkbox">
   <label>
     <input type="checkbox"> Refrances
   </label>
 </div>

   <div class="checkbox">
   <label>
     <input type="checkbox"> Tecnical Brakdown
   </label>
 </div>
   <div class="checkbox">
   <label>
     <input type="checkbox"> Staged Development Planing
   </label>
 </div>
 <div class="checkbox">
   <label>
     <input type="checkbox"> Enverment Setup
   </label>
 </div>
   <div class="checkbox"> 
   <label>
     <input type="checkbox"> Workflow

   </label>
 </div>
  
  
</form>
  </div></div></div>

      </p>
    </div>

    <div class="steps-two">
      <img class="steps-img" src="http://placehold.it/50/3498DB/FFFFFF" alt="" />
      <h3 class="steps-name">
          Model
        </h3>
      <p class="steps-description">
<div class="row"><div class="col-md-9">
<form role="form" style="margin-left: 85px">
 
 <div class="checkbox">
   <label>
     <input type="checkbox"> Drawings(T-ARt)

   </label>
 </div>

   <div class="checkbox"> 
   <label>
     <input type="checkbox"> Rigging
   </label>
 </div>
   <div class="checkbox">
   <label>
     <input type="checkbox">  motion capture
   </label>
 </div>
   <div class="checkbox">
   <label>
     <input type="checkbox"> AR
   </label>
 </div>
   
  <div class="checkbox">
   <label>
     <input type="checkbox"> Scene Acting
   </label>
 </div>
  <div class="checkbox">
   <label>
     <input type="checkbox"> Level Design
   </label>
 </div>
</form>
  </div></div></div>


    <div class="steps-three">
      <img class="steps-img" src="http://placehold.it/50/3498DB/FFFFFF" alt="" />
      <h3 class="steps-name">
          Gamefy
        </h3>
      <p class="steps-description">
        <div class="container"><div class="row"><div class="col-md-6">
<form role="form"  style="margin-left: 85px">
 
 <div class="checkbox">
   <label>
     <input type="checkbox"> Topics (Pdf)
   </label>
 </div>

   <div class="checkbox">
   <label>
     <input type="checkbox"> Database (repository)

   </label>
 </div>
   <div class="checkbox">
   <label>
     <input type="checkbox"> Projects 

   </label>
 </div>
   <div class="checkbox">
   <label>
     <input type="checkbox"> Assets

</label>
 </div>
   <div class="checkbox">
   <label>
     <input type="checkbox"> Tools

   </label>
 </div>
  
</form>
  </div></div></div>

      </p>
    </div>
  <!-- /.steps-timeline -->

</section>
  
  </div>
   
<div class="col-lg-12" style="margin-left: 155px">


<ul class="tabs" data-tabs id="example-tabs">
<li class="tabs-title is-active"><a href="#panel1" aria-selected="true">The Idea</a></li><!--Name, Goals, Experince, Skills, Education-->
<li class="tabs-title"><a href="#panel2">Script </a></li><!-- Business Development, Sales, Digital Marketing, Web design, Video Production -->
<li class="tabs-title"><a href="#panel3">Thumbnail</a></li><!--2010, 2012, 2014, 15, 16, 17, 18, 19, 20-->
<li class="tabs-title"><a href="#panel4">Rough Draft</a></li><!--Bant-->
<li class="tabs-title"><a href="#panel5">Refine Draft</a></li><!--Job, Duty, Goals, actions, Results-->
<li class="tabs-title"><a href="#panel6">Storyboard</a></li> <!--Person, Role, Relastionship, Quite-->
<li class="tabs-title"><a href="#panel6">modeling</a></li><!--Situation, Task, Action, Results-->
<li class="tabs-title"><a href="#panel7">Texture</a></li><!--Job, Duty, Goals, actions, Results-->

<li class="tabs-title"><a href="#panel8">Game design</a></li><!--Job, Duty, Goals, actions, Results-->

<li class="tabs-title"><a href="#panel9">game Programing</a></li><!--Job, Duty, Goals, actions, Results-->

<li class="tabs-title"><a href="#panel10">Marketplace</a></li><!--Job, Duty, Goals, actions, Results-->
</ul>

<div class="tabs-content" data-tabs-content="example-tabs">

<!--Pannel1-->    
    <div class="tabs-panel is-active" id="panel1">
    <div class="row">
    <div class="media-object stack-for-small">
       


      <div>Begin <hr>
      <div class="gridly">
   
     
      
  <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="books/book/<?= $review['book_id']; ?>/"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             </div>
             <div>Begin REF's <hr>
       <div class="gridly">
   
     
      
  <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             </div>
              <div>Middle <hr>
               <div class="gridly">
   
     
      
  <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             </div>
              <div>Middle Ref's <hr>
               <div class="gridly">
   <div class="gridly">
   
     
      
  <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             </div>
             <div>End <hr>
                <div class="gridly">
   
     
      
  <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             </div>
             <div>End Ref<hr>
                <div class="gridly">
   
     
      
  <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             </div>
               
                      
             </div>
</div>
       
              </div> 
            
                
            </div>
            </div>
            </div>
<div class="col-lg-9">


 <form action="createReview" method="post">

       <div class="form-group">
     <label for="photo">Photo:</label>
	 	<input type="file" name="photo" class="form-control" id="photo" value="" placeholder="photo">
	 </div>
      <div class="form-group">
                <label for="title">Topic:</label>
                <input type="text" name="title" class="form-control" id="title" placeholder="Book Title">
              </div>
              <div class="form-group">
                <label for="author">Author:</label>
                <input type="text" name="author" class="form-control" id="author" placeholder="Author Name">
              </div>
              <div class="form-group">
                <label for="review">Review:</label>
                <textarea class="form-control" rows="6" name="review" id="review">Write your review...</textarea>
              </div>
              <div class="form-group">
                <label for="rating">Rating:</label>
                <select class="form-control" name="rating" id="rating">
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                </select>
              </div>
              <div class="form-group">
                <label for="stage">Stage:</label>



                <select class="form-control" name="stage" id="stage">
                  <option value="User_Profile">User_Profile</option>
                  <option value="Name">Name</option>
                   <option value="Goals">Goals</option>
                    <option value="Experince">Experince</option>
                     <option value="Skills">Skills</option>
                      <option value="Educaton">Education</option>
                      <option value="Stoyboard">Storyboard</option>
                    <option value="Idea(End)">Idea(End)</option>

                  <option value="Course_Request">Course_Request</option>
                  
                </select>
              </div>
              

              <input type="hidden" name="user_id" value="<?= $this->session->userdata('user_id'); ?>">
              <input type="submit" class="btn btn-info pull-right" value="Add My Review">
            </form>
            <br>
            <hr>
              <h3>Create A Business Case</h3>
              <h4>Ask what the client is useing on prem in there datacenter. How many severs how many client facing applications. Spesific specs. Input this infomation in the TCO Calculater bellow.</h4>
       
          

<hr>
                             <h3>Create Course</h3>
                                                                            <div>
                                                                                <p>
                                                                                
  <h3>Add a new course&lt;/h3>
  <form action='<?php echo base_url('/courses/add'); ?>' method='post'>
    <label>Name:
      <input type='text' name='name' />
    </label>
    <br />
    <label>Description:
      <textarea name='description'></textarea>
    </label>
    <br />
    <input type='submit' value='Add' />
  </form>

<?php echo $this->session->flashdata('message'); ?>

  <h3>Courses</h3>
  <table>
    <thead>
      <tr>
        <th>Course Name</th>
        <th>Description</th>
        <th>Date Added</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
<?php
      //var_dump($courses);

      foreach ($courses as $course_data) 
      {
        $date_added = date('F d, Y', strtotime($course_data['created_at']));
        
        echo "<tr>
            <td>". $course_data['name'] . "</td>
            <td>". $course_data['description'] . "</td>
            <td>". $date_added . "</td>
            <td><a href= 'courses/destroy/". $course_data['id']. "'>Remove</a></td>
        </tr>";
      }
?>
    </tbody>
  </table>
                                                                               
                    </div>                                                        
                                                                            </div>
  </div>
</div>



                                                         
                                                                            </div> 
                                                                            </div><!--Pannel1-->
                                                                            
                                                                            <!--Pannel2--><!--(skills) Business Development, Sales, Digital Marketing, Web design, Video Production, Developer Entrepreneur --> <div class="tabs-panel is-active" id="panel1">
    <div class="row">
    <div class="media-object stack-for-small">
       


      <div>Begin <hr>
      <div class="gridly">
   
     
      
  <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="books/book/<?= $review['book_id']; ?>/"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             </div>
             <div>Begin REF's <hr>
       <div class="gridly">
   
     
      
  <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             </div>
              <div>Middle <hr>
               <div class="gridly">
   
     
      
  <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             </div>
              <div>Middle Ref's <hr>
               <div class="gridly">
   <div class="gridly">
   
     
      
  <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             </div>
             <div>End <hr>
                <div class="gridly">
   
     
      
  <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             </div>
             <div>End Ref<hr>
                <div class="gridly">
   
     
      
  <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             </div>
               
                      
             </div>
</div>
       
              </div> 
            
                
            </div>
            </div>
            </div>
<div class="col-lg-9">


 <form action="createReview" method="post">

       <div class="form-group">
     <label for="photo">Photo:</label>
	 	<input type="file" name="photo" class="form-control" id="photo" value="" placeholder="photo">
	 </div>
      <div class="form-group">
                <label for="title">Topic:</label>
                <input type="text" name="title" class="form-control" id="title" placeholder="Book Title">
              </div>
              <div class="form-group">
                <label for="author">Author:</label>
                <input type="text" name="author" class="form-control" id="author" placeholder="Author Name">
              </div>
              <div class="form-group">
                <label for="review">Review:</label>
                <textarea class="form-control" rows="6" name="review" id="review">Write your review...</textarea>
              </div>
              <div class="form-group">
                <label for="rating">Rating:</label>
                <select class="form-control" name="rating" id="rating">
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                </select>
              </div>
              <div class="form-group">
                <label for="stage">Stage:</label>



                <select class="form-control" name="stage" id="stage">
                  <option value="User_Profile">User_Profile</option>
                  <option value="Name">Name</option>
                   <option value="Goals">Goals</option>
                    <option value="Experince">Experince</option>
                     <option value="Skills">Skills</option>
                      <option value="Educaton">Education</option>
                      <option value="Stoyboard">Storyboard</option>
                    <option value="Idea(End)">Idea(End)</option>

                  <option value="Course_Request">Course_Request</option>
                  
                </select>
              </div>
              

              <input type="hidden" name="user_id" value="<?= $this->session->userdata('user_id'); ?>">
              <input type="submit" class="btn btn-info pull-right" value="Add My Review">
            </form>
            <br>
            <hr>
              <h3>Create A Business Case</h3>
              <h4>Ask what the client is useing on prem in there datacenter. How many severs how many client facing applications. Spesific specs. Input this infomation in the TCO Calculater bellow.</h4>
       
          

<hr>
                             <h3>Create Course</h3>
                                                                            <div>
                                                                                <p>
                                                                                
  <h3>Add a new course&lt;/h3>
  <form action='<?php echo base_url('/courses/add'); ?>' method='post'>
    <label>Name:
      <input type='text' name='name' />
    </label>
    <br />
    <label>Description:
      <textarea name='description'></textarea>
    </label>
    <br />
    <input type='submit' value='Add' />
  </form>

<?php echo $this->session->flashdata('message'); ?>

  <h3>Courses</h3>
  <table>
    <thead>
      <tr>
        <th>Course Name</th>
        <th>Description</th>
        <th>Date Added</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
<?php
      //var_dump($courses);

      foreach ($courses as $course_data) 
      {
        $date_added = date('F d, Y', strtotime($course_data['created_at']));
        
        echo "<tr>
            <td>". $course_data['name'] . "</td>
            <td>". $course_data['description'] . "</td>
            <td>". $date_added . "</td>
            <td><a href= 'courses/destroy/". $course_data['id']. "'>Remove</a></td>
        </tr>";
      }
?>
    </tbody>
  </table>
                                                                               
                    </div>                                                        
                                                                            </div>
  </div>
</div>



                                                         
                                                                            </div> 
                                                                            </div>
                                                                            
                                                                            
                                                                           <div class="tabs-panel is-active" id="panel2">
    <div class="row">
    <div class="media-object stack-for-small">
       


      <div>Begin <hr>
      <div class="gridly">
   
     
      
  <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="books/book/<?= $review['book_id']; ?>/"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             </div>
             <div>Begin REF's <hr>
       <div class="gridly">
   
     
      
  <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             </div>
              <div>Middle <hr>
               <div class="gridly">
   
     
      
  <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             </div>
              <div>Middle Ref's <hr>
               <div class="gridly">
   <div class="gridly">
   
     
      
  <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             </div>
             <div>End <hr>
                <div class="gridly">
   
     
      
  <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             </div>
             <div>End Ref<hr>
                <div class="gridly">
   
     
      
  <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "The_Idea"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
             </div>
               
                      
             </div>
</div>
       
              </div> 
            
                
            </div>
            </div>
            </div>
<div class="col-lg-9">


 <form action="createReview" method="post">

       <div class="form-group">
     <label for="photo">Photo:</label>
	 	<input type="file" name="photo" class="form-control" id="photo" value="" placeholder="photo">
	 </div>
      <div class="form-group">
                <label for="title">Topic:</label>
                <input type="text" name="title" class="form-control" id="title" placeholder="Book Title">
              </div>
              <div class="form-group">
                <label for="author">Author:</label>
                <input type="text" name="author" class="form-control" id="author" placeholder="Author Name">
              </div>
              <div class="form-group">
                <label for="review">Review:</label>
                <textarea class="form-control" rows="6" name="review" id="review">Write your review...</textarea>
              </div>
              <div class="form-group">
                <label for="rating">Rating:</label>
                <select class="form-control" name="rating" id="rating">
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                </select>
              </div>
              <div class="form-group">
                <label for="stage">Stage:</label>



                <select class="form-control" name="stage" id="stage">
                  <option value="User_Profile">User_Profile</option>
                  <option value="Name">Name</option>
                   <option value="Goals">Goals</option>
                    <option value="Experince">Experince</option>
                     <option value="Skills">Skills</option>
                      <option value="Educaton">Education</option>
                      <option value="Stoyboard">Storyboard</option>
                    <option value="Idea(End)">Idea(End)</option>

                  <option value="Course_Request">Course_Request</option>
                  
                </select>
              </div>
              

              <input type="hidden" name="user_id" value="<?= $this->session->userdata('user_id'); ?>">
              <input type="submit" class="btn btn-info pull-right" value="Add My Review">
            </form>
            <br>
            <hr>
              <h3>Create A Business Case</h3>
              <h4>Ask what the client is useing on prem in there datacenter. How many severs how many client facing applications. Spesific specs. Input this infomation in the TCO Calculater bellow.</h4>
       
          

<hr>
                             <h3>Create Course</h3>
                                                                            <div>
                                                                                <p>
                                                                                
  <h3>Add a new course&lt;/h3>
  <form action='<?php echo base_url('/courses/add'); ?>' method='post'>
    <label>Name:
      <input type='text' name='name' />
    </label>
    <br />
    <label>Description:
      <textarea name='description'></textarea>
    </label>
    <br />
    <input type='submit' value='Add' />
  </form>

<?php echo $this->session->flashdata('message'); ?>

  <h3>Courses</h3>
  <table>
    <thead>
      <tr>
        <th>Course Name</th>
        <th>Description</th>
        <th>Date Added</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
<?php
      //var_dump($courses);

      foreach ($courses as $course_data) 
      {
        $date_added = date('F d, Y', strtotime($course_data['created_at']));
        
        echo "<tr>
            <td>". $course_data['name'] . "</td>
            <td>". $course_data['description'] . "</td>
            <td>". $date_added . "</td>
            <td><a href= 'courses/destroy/". $course_data['id']. "'>Remove</a></td>
        </tr>";
      }
?>
    </tbody>
  </table>
                                                                               
                    </div>                                                        
                                                                            </div>
  </div>
</div>



                                                         
                                                                            </div> 
                                                                            </div> 
                                                                            <pannel3></pannel3>
                                                                            </div>
                                                                            
                                                                           
  

 

    <!-- Bootstrap Core JavaScript -->
    <script src="/js/bootstrap.min.js"></script>




<script>function inject(){function a(){function a(a){parent.postMessage({type:"blockedWindow",args:JSON.stringify(a)},l)}function b(a){var b=a[1];return null!=b&&["_blank","_parent","_self","_top"].indexOf(b)<0?b:null}function e(a,b){var c;for(c in a)try{void 0===b[c]&&(b[c]=a[c])}catch(d){}return b}var g=arguments,h=!0,j=null,k=null;if(null!=window.event&&(k=window.event.currentTarget),null==k){for(var m=g.callee;null!=m.arguments&&null!=m.arguments.callee.caller;)m=m.arguments.callee.caller;null!=m.arguments&&m.arguments.length>0&&null!=m.arguments[0].currentTarget&&(k=m.arguments[0].currentTarget)}null!=k&&(k instanceof Window||k===document||null!=k.URL&&null!=k.body||null!=k.nodeName&&("body"==k.nodeName.toLowerCase()||"#document"==k.nodeName.toLowerCase()))?(window.pbreason="Blocked a new window opened with URL: "+g[0]+" because it was triggered by the "+k.nodeName+" element",h=!1):h=!0;document.webkitFullscreenElement||document.mozFullscreenElement||document.fullscreenElement;if(((new Date).getTime()-d<1e3||isNaN(d)&&c())&&(window.pbreason="Blocked a new window opened with URL: "+g[0]+" because a full screen was just initiated while opening this url.",document.exitFullscreen?document.exitFullscreen():document.mozCancelFullScreen?document.mozCancelFullScreen():document.webkitCancelFullScreen&&document.webkitCancelFullScreen(),h=!1),1==h){j=f.apply(this,g);var n=b(g);if(null!=n&&(i[n]=j),j!==window){var o=(new Date).getTime(),p=j.blur;j.blur=function(){(new Date).getTime()-o<1e3?(window.pbreason="Blocked a new window opened with URL: "+g[0]+" because a it was blured",j.close(),a(g)):p()}}}else{var q={href:g[0]};q.replace=function(a){q.href=a},j={close:function(){return!0},test:function(){return!0},blur:function(){return!0},focus:function(){return!0},showModelessDialog:function(){return!0},showModalDialog:function(){return!0},prompt:function(){return!0},confirm:function(){return!0},alert:function(){return!0},moveTo:function(){return!0},moveBy:function(){return!0},resizeTo:function(){return!0},resizeBy:function(){return!0},scrollBy:function(){return!0},scrollTo:function(){return!0},getSelection:function(){return!0},onunload:function(){return!0},print:function(){return!0},open:function(){return this},opener:window,closed:!1,innerHeight:480,innerWidth:640,name:g[1],location:q,document:{location:q}},e(window,j),j.window=j;var n=b(g);if(null!=n)try{i[n].close()}catch(r){}setTimeout(function(){var b;b=j.location instanceof Object?j.document.location instanceof Object?null!=q.href?q.href:g[0]:j.document.location:j.location,g[0]=b,a(g)},100)}return j}function b(a){d=a?(new Date).getTime():0/0}function c(){return document.fullScreenElement&&null!==document.fullScreenElement||null!=document.mozFullscreenElement||null!=document.webkitFullscreenElement}var d,e="originalOpenFunction",f=window.open,g=document.createElement,h=document.createEvent,i={},j=0,k=null,l=window.location!=window.parent.location?document.referrer:document.location;window[e]=window.open,window.open=function(){try{return a.apply(this,arguments)}catch(b){return null}},document.createElement=function(){var a=g.apply(document,arguments);if("a"==arguments[0]||"A"==arguments[0]){j=(new Date).getTime();var b=a.dispatchEvent;a.dispatchEvent=function(c){return null!=c.type&&"click"==(""+c.type).toLocaleLowerCase()?(window.pbreason="blocked due to an explicit dispatchEvent event with type 'click' on an 'a' tag",parent.postMessage({type:"blockedWindow",args:JSON.stringify({0:a.href})},l),!0):b(c)},k=a}return a},document.createEvent=function(){try{return arguments[0].toLowerCase().indexOf("mouse")>=0&&(new Date).getTime()-j<=50?(window.pbreason="Blocked because 'a' element was recently created and "+arguments[0]+" event was created shortly after",arguments[0]=k.href,parent.postMessage({type:"blockedWindow",args:JSON.stringify({0:k.href})},l),null):h.apply(document,arguments)}catch(a){}},document.addEventListener("fullscreenchange",function(){b(document.fullscreen)},!1),document.addEventListener("mozfullscreenchange",function(){b(document.mozFullScreen)},!1),document.addEventListener("webkitfullscreenchange",function(){b(document.webkitIsFullScreen)},!1)} inject()</script>
                                                                                      
               

<script src="http://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.js"></script>
<script>
      $(document).foundation();
    </script>
    <script>
$("input").change(function(e) {

    for (var i = 0; i < e.originalEvent.srcElement.files.length; i++) {
        
        var file = e.originalEvent.srcElement.files[i];
        
        var img = document.createElement("img");
        var reader = new FileReader();
        reader.onloadend = function() {
             img.src = reader.result;
        }
        reader.readAsDataURL(file);
        $("input").after(img);
    }
});
    </script>
    <script>
function myFunction() {
   if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#blah').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
    }
}
</script>
<script>

</script>
</body>
</html>