angular-dojo
============

AngularJS directives for dojo widgets

Usage
-----
eg:
```<script src='directives/angular-dojo.js'></script>```

```
angular.module('app', [
	'angular-dojo'
]);
```

Examples
--------
See [test.html](test.html)

License
-------
*angular-dojo* may be used under the terms of the MIT license, see [LICENSE](LICENSE)
