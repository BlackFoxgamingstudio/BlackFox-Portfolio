# AngularJS Coding Dojo

## Table of Contents

1. What we will be building
2. What is AngularJS and what it is not
3. Getting started
4. Modules
  1. Getter and setter syntax
  2. Modules best practices
5. Bindings, expressions and AngularJS magics
  1. Two way data binding
  2. One way data binding
6. Dependency injection
7. Routing with UI Router
8. Controllers, scopes and root scope
  1. Scope members
  2. Listening scope changes
  3. $apply, $digest and $$phase
9. Services
  1. Using ngResource
  2. Custom services
  3. Services best practices or why you should move all the logic from controllers to Services
10. Working with models
  1. Creating models in the view
  2. Listening for changes in models
  3. Form validation
11. Directives
12. Filters
13. How to use promises
  1. How to use $q
  2. How to use $http
  3. Differences between $q and $http
14. Internationalization and Localization with gettext
15. Include custom HTML views
16. Testing with Jasmine
  1. Mocking data
  2. Mocking services
  3. Using $httpBackend

## Getting Started

### Prerequisites

- [Git](https://git-scm.com/)
- [Node.js and npm](nodejs.org) Node ^4.2.3, npm ^2.14.7
- [Bower](bower.io) (`npm install --global bower`)
- [Ruby](https://www.ruby-lang.org) and then `gem install sass`
- [Gulp](http://gulpjs.com/) (`npm install --global gulp`)
- [MongoDB](https://www.mongodb.org/) - Keep a running daemon with `mongod`

### Developing

1. Run `npm install` to install server dependencies.

2. Run `bower install` to install front-end dependencies.

3. Run `mongod` in a separate shell to keep an instance of the MongoDB Daemon running

4. Run `gulp serve` to start the development server. It should automatically open the client in your browser when ready.

## Build & development

Run `grunt build` for building and `grunt serve` for preview.

## Testing

Running `npm test` will run the unit tests with karma.
