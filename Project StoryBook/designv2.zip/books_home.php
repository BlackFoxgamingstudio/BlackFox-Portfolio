<?php 
  $this->load->view('partials/head');
?>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Dreamlancer 0-100 Design</title>
  
  <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
 <script src="http://codeorigin.jquery.com/jquery-1.10.2.min.js" type="text/javascript"></script>
  <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="http://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.min.css">
<!-- jQuery library -->
<script type="text/javascript" src="/assets/js/jquery-1.10.2.js"></script>
<script type="text/javascript" src="/assets/js/jquery-ui-1.10.4.custom.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	<link href='https://fonts.googleapis.com/css?family=Playfair+Display:700,900|Fira+Sans:400,400italic' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" href="/assets/css/style.css"> <!-- Resource style -->

 <script src="/assets/js/script2.js"></script>
 
<!--Latest compiled JavaScript -->
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
 <!-- Latest compiled and minified CSS -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js" type="text/javascript"></script>

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<!-- Latest compiled JavaScript -->
 <link href='https://fonts.googleapis.com/css?family=Lato' rel='stylesheet' >
      <link href='/assets/stylesheets/jquery.gridly.css' rel='stylesheet' >
      
      <script src='/assets/javascripts/jquery.js'></script>
     
      <script src='/assets/javascripts/sample.js' ></script>
      <script src='/assets/javascripts/rainbow.js' ></script>
      <script>
        
      </script>
  
 
    <link href='https://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
      <link href='/assets/stylesheets/jquery.gridly.css' rel='stylesheet' type='text/css'>
     
      <script src='/assets/javascripts/jquery.js' type='text/javascript'></script>
      <script src='/assets/javascripts/jquery.gridly.js' type='text/javascript'></script>
      <script src='/assets/javascripts/sample.js' type='text/javascript'></script>
      <script src='/assets/javascripts/rainbow.js' type='text/javascript'></script>
 
<script>
  $('.gridly').gridly({
    base: 60, // px 
    gutter: 20, // px
    columns: 12
  });
  $('.brick').ondblclick(function() {
    $this = $(this);

    // toggle the size of the brick using css class
    $this.toggleClass('large').toggleClass('small');

    // this is set to ensure the layout is carried out on the final size of the brick
    size = $this.hasClass('small') ? 140 : 300;
    $this.data('width', size);
    $this.data('height', size);

    return $('.gridly').gridly('layout');
  });

</script>
 <script>
    
    //read input url
   function readURL(input) {

    if (input.files && input.files[0]) {
        var reader = new FileReader();

// at location
        reader.onload = function (e) {
            $('#blah1').attr('src', e.target.result);
            
        }

        reader.readAsDataURL(input.files['0']);
    }
    
}

$("#imgInp").change(function(){
    readURL(this);
});
</script>

</script>
<STYLE>
@import url(http://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic);
html {
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: inherit;
}

  .gridly {
    position: relative;
    width: 960px;
  }
  .brick {
    overflow: hidden;
  }
  .brick img {
    padding: 10px;
  }
  .brick div {
    padding: 0 10px 0 10px;
  }
  .brick.small {
    width: 140px;
    height: 140px;
    background-color: gray;
  }
  .brick.large {
    width: 300px;
    height: 300px;
    background-color: #B0B0B0;
  }

@media screen and (max-width: 500px) {
  .steps-timeline {
    border-left: 2px solid #3498DB;
    margin-left: 25px;
  }
}
@media screen and (min-width: 500px) {
  .steps-timeline {
    border-top: 2px solid #3498DB;
    padding-top: 20px;
    margin-top: 40px;
    margin-left: 16.65%;
    margin-right: 16.65%;
  }
}
.steps-timeline:after {
  content: "";
  display: table;
  clear: both;
}

.steps-one,
.steps-two,
.steps-three {
  outline: 1px dashed rgba(0, 128, 0, 0);
}
@media screen and (max-width: 500px) {
  .steps-one,
  .steps-two,
  .steps-three {
    margin-left: -25px;
  }
}
@media screen and (min-width: 500px) {
  .steps-one,
  .steps-two,
  .steps-three {
    float: left;
    width: 33%;
    margin-top: -50px;
  }
}

@media screen and (max-width: 500px) {
  .steps-one,
  .steps-two {
    padding-bottom: 40px;
  }
}

@media screen and (min-width: 500px) {
  .steps-one {
    margin-left: -16.65%;
    margin-right: 16.65%;
  }
}

@media screen and (max-width: 500px) {
  .steps-three {
    margin-bottom: -100%;
  }
}
@media screen and (min-width: 500px) {
  .steps-three {
    margin-left: 16.65%;
    margin-right: -16.65%;
  }
}

.steps-img {
  display: block;
  margin: auto;
  width: 50px;
  height: 50px;
  border-radius: 50%;
}
@media screen and (max-width: 500px) {
  .steps-img {
    float: left;
    margin-right: 20px;
  }
}

.steps-name,
.steps-description {
  margin: 0;
}

@media screen and (min-width: 500px) {
  .steps-name {
    text-align: center;
  }
}

.steps-description {
  overflow: hidden;
}
@media screen and (min-width: 500px) {
  .steps-description {
    text-align: center;
  }
}


</STYLE>



 
</head>

<?php 
  $this->load->view('partials/navbar');
  $this->load->view('partials/messages');
  
?>
<?php     
  if($this->session->userdata('name'))
  {
?>          
   <center> <div class="container">
      <div class="row">
        <div class="col-lg-12">

          <center><h2>Welcome <?= $this->session->userdata('name'); ?></h2></center>
          <center><h1> Your Storyboard begins here!</h1></center>
        </div>
      </div>
    </div></center>
<?php     }
?>

<div id="myCarousel" class="carousel slide" data-ride="carousel">
      <!-- Indicators -->
      <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1" class=""></li>
        <li data-target="#myCarousel" data-slide-to="2" class=""></li>
      </ol>
      <div class="carousel-inner" role="listbox">
        <div class="item">
          <img class="first-slide" src="http://gdriv.es/heroimg1/
Untitled-2.jpg" alt="First slide">
        <div class="container">
            <div class="carousel-caption">
             
              <a class="btn btn-lg btn-primary" href="#" role="button">Learn more</a>
            </div>
          </div>
        </div>
        <div class="item">
          <img class="second-slide" src="http://gdriv.es/heroimg1/
Untitled-3.png" alt="Second slide">
          <div class="container">
            <div class="carousel-caption">
             
              <a class="btn btn-lg btn-primary" href="#" role="button">Learn more</a>
            </div>
          </div>
        </div>
        <div class="item active">
          <img class="third-slide" src="http://gdriv.es/heroimg1/

bannerADDSTest1.png" alt="Third slide">
          <div class="container">
            <div class="carousel-caption">
             
              <a class="btn btn-lg btn-primary" href="#" role="button">Learn more</a>
            </div>
          </div></div>
      </div>
      <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div>



<div class"col-lg-12 btn btn-info">
<!-- STEPS -->
<section id="Steps" class="steps-section">

  <h2 class="steps-header">
      Responsive Semantic Timeline
    </h2>

  <div class="steps-timeline">

    <div class="steps-one">
      <img class="steps-img" src="http://placehold.it/50/3498DB/FFFFFF" alt="" />
      <h3 class="steps-name">
          Sales
        </h3>
      <p class="steps-description">
        <div class="container"><div class="row"><div class="col-md-6">
<form role="form" style="margin-left: 85px">
 
 <div class="checkbox">
   <label>
     <input type="checkbox"> Baseball/Marketing
   </label>
 </div>

   <div class="checkbox">
   <label>
     <input type="checkbox"> Game Stop
   </label>
 </div>
   <div class="checkbox">
   <label>
     <input type="checkbox"> Enterpirse Rent A Car
   </label>
 </div>
 <div class="checkbox">
   <label>
     <input type="checkbox"> Microsoft @ N3
   </label>
 </div>
   <div class="checkbox"> 
   <label>
     <input type="checkbox"> Amazon @ CSG 

   </label>
 </div>
  
  
</form>
  </div></div></div>

      </p>
    </div>

    <div class="steps-two">
      <img class="steps-img" src="http://placehold.it/50/3498DB/FFFFFF" alt="" />
      <h3 class="steps-name">
          Customer Service
        </h3>
      <p class="steps-description">
<div class="row"><div class="col-md-9">
<form role="form" style="margin-left: 85px">
 
 <div class="checkbox">
   <label>
     <input type="checkbox"> Edward Martin (CIO)

   </label>
 </div>

   <div class="checkbox">
   <label>
     <input type="checkbox"> Omar Mehilba (Microsoft Manager)
   </label>
 </div>
   <div class="checkbox">
   <label>
     <input type="checkbox">  Scott Holland (Hosting Services Manager)
   </label>
 </div>
   <div class="checkbox">
   <label>
     <input type="checkbox"> Matthew Peteshel (CSG CLient Services Director)
   </label>
 </div>
   
  <div class="checkbox">
   <label>
     <input type="checkbox">Adam & Andrew Powers (Keytech labs Founders & Brothers)
   </label>
 </div>
  
</form>
  </div></div></div>


    <div class="steps-three">
      <img class="steps-img" src="http://placehold.it/50/3498DB/FFFFFF" alt="" />
      <h3 class="steps-name">
          Networking
        </h3>
      <p class="steps-description">
        <div class="container"><div class="row"><div class="col-md-6">
<form role="form"  style="margin-left: 85px">
 
 <div class="checkbox">
   <label>
     <input type="checkbox"> Seattle University

   </label>
 </div>

   <div class="checkbox">
   <label>
     <input type="checkbox"> Microsoft @ N3 (Manager and teammates)

   </label>
 </div>
   <div class="checkbox">
   <label>
     <input type="checkbox"> Amazon @ CSG (Manager and Lead Gen Team)

   </label>
 </div>
   <div class="checkbox">
   <label>
     <input type="checkbox"> KeyTech Labs (Kids)

   </label>
 </div>
  
</form>
  </div></div></div>

      </p>
    </div>
  <!-- /.steps-timeline -->

</section>
  
  </div>
   
<div class="col-lg-12" style="margin-left: 155px">

<hr>
<ul class="tabs" data-tabs id="example-tabs">
<li class="tabs-title is-active"><a href="#panel1" aria-selected="true">User Profile</a></li><!--Name, Goals, Experince, Skills, Education-->
<li class="tabs-title"><a href="#panel2">Skills</a></li><!-- Business Development, Sales, Digital Marketing, Web design, Video Production -->
<li class="tabs-title"><a href="#panel3">Education RoadMap</a></li><!--2010, 2012, 2014, 15, 16, 17, 18, 19, 20-->
<li class="tabs-title"><a href="#panel4">Appointments</a></li><!--Bant-->
<li class="tabs-title"><a href="#panel5">Experince</a></li><!--Job, Duty, Goals, actions, Results-->
<li class="tabs-title"><a href="#panel6">Network</a></li> <!--Person, Role, Relastionship, Quite-->
<li class="tabs-title"><a href="#panel6">Accomplishments</a></li><!--Situation, Task, Action, Results-->
<li class="tabs-title"><a href="#panel7">Vocie of the Customer</a></li><!--Job, Duty, Goals, actions, Results-->
</ul>

<div class="tabs-content" data-tabs-content="example-tabs">

<!--Pannel1-->    
    <div class="tabs-panel is-active" id="panel1">
    <div class="row">
    <div class="media-object stack-for-small">
       


     
      <div class="gridly">
  
  <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "19")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah1" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah1').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                                                     <center><div class="col-sm-9">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "20")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah2" alt="your image" width="400" height="400" />

<input type="file" 
    onchange="document.getElementById('blah2').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
  <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "21")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
            <div class="col-md-30 btn-default review" align="center">
                               <img id="blah3" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah3').src = window.URL.createObjectURL(this.files[0])">
                              
                        <div class="col-md-20 btn-default review" align="center">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
 <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "22")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                              <div class="col-md-30 btn-default review" align="center">
                               <img id="blah4" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah4').src = window.URL.createObjectURL(this.files[0])">
                             
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
  <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "23")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
                           
                               <div class="col-md-30 btn-default review" align="center">
                               <img id="blah5" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah5').src = window.URL.createObjectURL(this.files[0])">
                             
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
 <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "24")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah6" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah6').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>">
                                      <h4><?= $review['photo']; ?></h4></a>
                                      <h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
 <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "25")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah7" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah7').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
 <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "26")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                      <div class="col-md-30 btn-default review" align="center">
                               <img id="blah8" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah8').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
  <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "27")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah9" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah9').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
 <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "28")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-30 btn-default review" align="center">
                               <img id="blah10" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah10').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
  <div class="brick large">                                                     <center><div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['book_id'] == "29")
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                       <div class="col-md-30 btn-default review" align="center">
                               <img id="blah11" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah11').src = window.URL.createObjectURL(this.files[0])">
                                  
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div><center>                                                                                       
                      
             </div>
</div>
       
                                                      <div class="container">
                                                            <div class="row">
                                                                  <div class="col-sm-12">
                                                                   
              <!-- Reviews Loop Begins -->
              <?php   $count=0;
                      foreach ($reviews as $review) 
                      if( $review['stage'] == "User_Profile"){
                      
                      if($count==3) break;
              ?> 
              
                        <div class="col-md-9 btn-default review" align="center">
                               <img id="blah12" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah12').src = window.URL.createObjectURL(this.files[0])">
                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      ?>          <br>
                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div>                                                                                       
                       </div>
                    </div>
                   <hr>
             
       
            <!--CXO pOSTE DIV--><!--Name, Goals, Experince, Skills, Education-->
                <div class="col-sm-9">
                                      <div name="review" style="">Name <hr>
                                                      <div class="container">
                                                            <div class="row">
                                                                  <div class="col-sm-12">
                                                                   
                                                                          <!-- Reviews Loop Begins -->
                                                                          <?php   $count=0;
                                                                                  foreach ($reviews as $review) 
                                                                                  if( $review['stage'] == "Name"){
                                                                                  
                                                                                  if($count==3) break;
                                                                          ?> 
                                                                                  <div class="col-md-30 btn-default review" align="center">
                               <img id="blah13" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah13').src = window.URL.createObjectURL(this.files[0])">
                                                                                      <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                                                                      <label class="inline">Rating :</label>
                                                                          <?php       for($i=0; $i<$review['stage']; $i++)
                                                                                      {
                                                                          ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                                                          <?php       }
                                                                          ?>          <br>
                                                                                      <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                                                                      <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                                                                      <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                                                                    </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div>                                                                                       
                       </div>
                    </div>
                   <hr>
                </div>
              </div> 
            
    <!--Goals pOSTE DIV-->
    <div class="col-sm-9">
                                      <div name="review" style="">Goals <hr>
                                                      <div class="container">
                                                            <div class="row">
                                                                  <div class="col-sm-5">
                                                                   
                                                                          <!-- Reviews Loop Begins -->
                                                                          <?php   $count=0;
                                                                                  foreach ($reviews as $review) 
                                                                                  if( $review['stage'] == "Goals"){
                                                                                  
                                                                                  if($count==3) break;
                                                                          ?> 
                                                                                  
                                                                                    <div class="col-md-30 btn-default review" align="center">
                               <img id="blah14" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah14').src = window.URL.createObjectURL(this.files[0])">
                                                                                      <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                                                                      <label class="inline">Rating :</label>
                                                                          <?php       for($i=0; $i<$review['stage']; $i++)
                                                                                      {
                                                                          ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                                                          <?php       }
                                                                          ?>          <br>
                                                                                      <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                                                                      <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                                                                      <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                                                                    </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div>                                                                                       
                       </div>
                    </div>
                   <hr>
                </div>
              </div> 
           
    <!--Experince pOSTE DIV-->
      <div class="col-sm-9">
                                      <div name="review" style="">Experince:<hr>
                                                      <div class="container">
                                                            <div class="row">
                                                                  <div class="col-sm-5">
                                                                   
                                                                          <!-- Reviews Loop Begins -->
                                                                          <?php   $count=0;
                                                                                  foreach ($reviews as $review) 
                                                                                  if( $review['stage'] == "Experince"){
                                                                                  
                                                                                  if($count==3) break;
                                                                          ?> 
                                                                                    <div class="col-lg-12 review">
                                                                                     <img id="blah15" alt="your image" width="250" height="250" />

<input type="file" 
    onchange="document.getElementById('blah15').src = window.URL.createObjectURL(this.files[0])">
                                                                                      <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                                                                      <label class="inline">Rating :</label>
                                                                          <?php       for($i=0; $i<$review['stage']; $i++)
                                                                                      {
                                                                          ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                                                          <?php       }
                                                                          ?>          <br>
                                                                                      <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                                                                      <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                                                                      <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                                                                    </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div>                                                                                       
                       </div>
                    </div>
                   <hr>
                </div>
              </div> 
         
        <!--Skills pOSTE DIV--><!--Disapline, Totoral, Assets, Projects-->
        <BR>
          <div class="col-sm-9">
                                      <div name="review" style="">Skills:<hr>
                                                      <div class="container">
                                                            <div class="row">
                                                                  <div class="col-sm-5">
                                                                   
                                                                          <!-- Reviews Loop Begins -->
                                                                          <?php   $count=0;
                                                                                  foreach ($reviews as $review) 
                                                                                  if( $review['stage'] == "Skills"){
                                                                                  
                                                                                  if($count==3) break;
                                                                          ?> 
                                                                                    <div class="col-lg-8 review">
                                                                                        <input type='file' id="imgInp" onchange="readURL(this);" />
        <img id="blah18" src="#" alt="your image" />
                                                                                      <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                                                                      <label class="inline">Rating :</label>
                                                                          <?php       for($i=0; $i<$review['stage']; $i++)
                                                                                      {
                                                                          ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                                                          <?php       }
                                                                          ?>          <br>
                                                                                      <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                                                                      <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                                                                      <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                                                                    </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div>                                                                                       
                       </div>
                    </div>
                   <hr>
                </div>
              </div> 
         
            <!--Education: pOSTE DIV-->
             <div class="col-sm-9">
                                      <div name="review" style="">Education: <hr>
                                                      <div class="container">
                                                            <div class="row">
                                                                  <div class="col-sm-5">
                                                                   
                                                                          <!-- Reviews Loop Begins -->
                                                                          <?php   $count=0;
                                                                                  foreach ($reviews as $review) 
                                                                                  if( $review['stage'] == "Education:"){
                                                                                  
                                                                                  if($count==3) break;
                                                                          ?> 
                                                                                    <div class="col-lg-8 review">
                                                                                        <input type='file' id="imgInp" onchange="readURL(this);" />
        <img id="blah17" src="#" alt="your image" />
                                                                                      <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                                                                      <label class="inline">Rating :</label>
                                                                          <?php       for($i=0; $i<$review['stage']; $i++)
                                                                                      {
                                                                          ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                                                          <?php       }
                                                                          ?>          <br>
                                                                                      <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                                                                      <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                                                                      <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                                                                    </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div>                                                                                       
                       </div>
                    </div>
                   <hr>
                </div>
              </div> 
            
                
            </div>
           
<div class="col-lg-9">


 <form action="createReview" method="post">

       <div class="form-group">
     <label for="photo">Photo:</label>
	 	<input type="file" name="photo" class="form-control" id="photo" value="" placeholder="photo">
	 </div>
      <div class="form-group">
                <label for="title">Topic:</label>
                <input type="text" name="title" class="form-control" id="title" placeholder="Book Title">
              </div>
              <div class="form-group">
                <label for="author">Author:</label>
                <input type="text" name="author" class="form-control" id="author" placeholder="Author Name">
              </div>
              <div class="form-group">
                <label for="review">Review:</label>
                <textarea class="form-control" rows="6" name="review" id="review">Write your review...</textarea>
              </div>
              <div class="form-group">
                <label for="rating">Rating:</label>
                <select class="form-control" name="rating" id="rating">
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                </select>
              </div>
              <div class="form-group">
                <label for="stage">Stage:</label>



                <select class="form-control" name="stage" id="stage">
                  <option value="User_Profile">User_Profile</option>
                  <option value="Name">Name</option>
                   <option value="Goals">Goals</option>
                    <option value="Experince">Experince</option>
                     <option value="Skills">Skills</option>
                      <option value="Educaton">Education</option>
                      <option value="Stoyboard">Storyboard</option>
                   
                  <option value="Course_Request">Course_Request</option>
                  
                </select>
              </div>
              

              <input type="hidden" name="user_id" value="<?= $this->session->userdata('user_id'); ?>">
              <input type="submit" class="btn btn-info pull-right" value="Add My Review">
            </form>
            <br>
            <hr>
              <h3>Create A Business Case</h3>
              <h4>Ask what the client is useing on prem in there datacenter. How many severs how many client facing applications. Spesific specs. Input this infomation in the TCO Calculater bellow.</h4>
       
          

<hr>
                             <h3>Create Course</h3>
                                                                            <div>
                                                                                <p>
                                                                                
  <h3>Add a new course&lt;/h3>
  <form action='<?php echo base_url('/courses/add'); ?>' method='post'>
    <label>Name:
      <input type='text' name='name' />
    </label>
    <br />
    <label>Description:
      <textarea name='description'></textarea>
    </label>
    <br />
    <input type='submit' value='Add' />
  </form>

<?php echo $this->session->flashdata('message'); ?>

  <h3>Courses</h3>
  <table>
    <thead>
      <tr>
        <th>Course Name</th>
        <th>Description</th>
        <th>Date Added</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
<?php
      //var_dump($courses);

      foreach ($courses as $course_data) 
      {
        $date_added = date('F d, Y', strtotime($course_data['created_at']));
        
        echo "<tr>
            <td>". $course_data['name'] . "</td>
            <td>". $course_data['description'] . "</td>
            <td>". $date_added . "</td>
            <td><a href= 'courses/destroy/". $course_data['id']. "'>Remove</a></td>
        </tr>";
      }
?>
    </tbody>
  </table>
                                                                               
                    </div>                                                        
                                                                            </div>
  </div>
</div>


<!--Pannel2--><!--(skills) Business Development, Sales, Digital Marketing, Web design, Video Production, Developer Entrepreneur -->

<div class="tabs-panel" id="panel2">


<div class="row">
    <div class="media-object stack-for-small">
        <div name="review" style="">Company ID <hr><br>
            Your IDeas Will Be posted HERE. Notes and Comments will be add by dreamlancers:).<hr>
                                                      <div class="container">
                                                            <div class="row">
                                                                  <div class="col-sm-5">
                                                                   
                                                                          <!-- Reviews Loop Begins -->
                                                                          <?php   $count=0;
                                                                                  foreach ($reviews as $review) 
                                                                                  if( $review['stage'] == "Company Infomation:"){
                                                                                  
                                                                                  if($count==3) break;
                                                                          ?> 
                                                                                    <div class="col-lg-8 review">
                                                                                        <input type='file' id="imgInp" onchange="readURL(this);" />
        <img id="blah" src="#" alt="your image" />
                                                                                      <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                                                                      <label class="inline">Rating :</label>
                                                                          <?php       for($i=0; $i<$review['stage']; $i++)
                                                                                      {
                                                                          ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                                                          <?php       }
                                                                          ?>          <br>
                                                                                      <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                                                                      <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                                                                      <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                                                                    </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div>                                                                                       
                       </div>
                    </div>
                    </div>
                   <hr>
             
    <!--Business Development: pOSTE DIV-->
      <div class="col-sm-9">
                                      <div name="review" style=""> Business Development<hr>
                                                      <div class="container">
                                                            <div class="row">
                                                                  <div class="col-sm-5">
                                                                   
                                                                          <!-- Reviews Loop Begins -->
                                                                          <?php   $count=0;
                                                                                  foreach ($reviews as $review) 
                                                                                  if( $review['stage'] == "Business_Development:"){
                                                                                  
                                                                                  if($count==3) break;
                                                                          ?> 
                                                                                    <div class="col-lg-8 review">
                                                                                      <input type='file' id="imgInp" onchange="readURL(this);" />
        <img id="blah" src="#" alt="your image" />
                                                                                      <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                                                                      <label class="inline">Rating :</label>
                                                                          <?php       for($i=0; $i<$review['stage']; $i++)
                                                                                      {
                                                                          ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                                                          <?php       }
                                                                          ?>          <br>
                                                                                      <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                                                                      <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                                                                      <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                                                                    </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div>                                                                                       
                       </div>
                    </div>
                   <hr>
                </div>
              </div> 
         
        <!--, Sales, pOSTE DIV--><BR>
          <div class="col-sm-9">
                                      <div name="review" style="">Sales:<hr>
                                                      <div class="container">
                                                            <div class="row">
                                                                  <div class="col-sm-5">
                                                                   
                                                                          <!-- Reviews Loop Begins -->
                                                                          <?php   $count=0;
                                                                                  foreach ($reviews as $review) 
                                                                                  if( $review['stage'] == "Sales:"){
                                                                                  
                                                                                  if($count==3) break;
                                                                          ?> 
                                                                                    <div class="col-lg-8 review">
                                                                                       <input type='file' id="imgInp" onchange="readURL(this);" />
        <img id="blah" src="#" alt="your image" />
                                                                                      <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                                                                      <label class="inline">Rating :</label>
                                                                          <?php       for($i=0; $i<$review['stage']; $i++)
                                                                                      {
                                                                          ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                                                          <?php       }
                                                                          ?>          <br>
                                                                                      <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                                                                      <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                                                                      <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                                                                    </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div>                                                                                       
                       </div>
                    </div>
                   <hr>
                </div>
              </div> 
         
            <!-- Digital Marketing pOSTE DIV-->
             <div class="col-sm-9">
                                      <div name="review" style="">Digital Marketing: <hr>
                                                      <div class="container">
                                                            <div class="row">
                                                                  <div class="col-sm-5">
                                                                   
                                                                          <!-- Reviews Loop Begins -->
                                                                          <?php   $count=0;
                                                                                  foreach ($reviews as $review) 
                                                                                  if( $review['stage'] == "Digital_Marketing:"){
                                                                                  
                                                                                  if($count==3) break;
                                                                          ?> 
                                                                                    <div class="col-lg-8 review">
                                                                                       <input type='file' id="imgInp" onchange="readURL(this);" />
        <img id="blah" src="#" alt="your image" />
                                                                                      <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                                                                      <label class="inline">Rating :</label>
                                                                          <?php       for($i=0; $i<$review['stage']; $i++)
                                                                                      {
                                                                          ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                                                          <?php       }
                                                                          ?>          <br>
                                                                                      <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                                                                      <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                                                                      <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                                                                    </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div>                                                                                       
                       </div>
                    </div>
                   <hr>
                </div>
              </div> 
            
                <!--, Web design: pOSTE DIV--> 
                <div class="col-sm-9">
                                      <div name="review" style="">Web Design: <hr>
                                                      <div class="container">
                                                            <div class="row">
                                                                  <div class="col-sm-5">
                                                                   
                                                                          <!-- Reviews Loop Begins -->
                                                                          <?php   $count=0;
                                                                                  foreach ($reviews as $review) 
                                                                                  if( $review['stage'] == "Web_Design:"){
                                                                                  
                                                                                  if($count==3) break;
                                                                          ?> 
                                                                                    <div class="col-lg-8 review">
                                                                                        <input type='file' id="imgInp" onchange="readURL(this);" />
        <img id="blah" src="#" alt="your image" />
                                                                                      <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                                                                      <label class="inline">Rating :</label>
                                                                          <?php       for($i=0; $i<$review['stage']; $i++)
                                                                                      {
                                                                          ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                                                          <?php       }
                                                                          ?>          <br>
                                                                                      <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                                                                      <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                                                                      <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                                                                    </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div>                                                                                       
                       </div>
                    </div>
                   <hr>
                </div>
              </div> 
              <!--, Video Production: pOSTE DIV-->
            
              
              <div class="col-sm-9">
                                      <div name="review" style="">Video Production: <hr>
                                                      <div class="container">
                                                            <div class="row">
                                                                  <div class="col-sm-5">
                                                                   
                                                                          <!-- Reviews Loop Begins -->
                                                                          <?php   $count=0;
                                                                                  foreach ($reviews as $review) 
                                                                                  if( $review['stage'] == "Video_Production:"){
                                                                                  
                                                                                  if($count==3) break;
                                                                          ?> 
                                                                                    <div class="col-lg-8 review">
                                                                                        <input type='file' id="imgInp" onchange="readURL(this);" />
        <img id="blah" src="#" alt="your image" />
                                                                                      <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                                                                      <label class="inline">Rating :</label>
                                                                          <?php       for($i=0; $i<$review['stage']; $i++)
                                                                                      {
                                                                          ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                                                          <?php       }
                                                                          ?>          <br>
                                                                                      <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                                                                      <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                                                                      <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                                                                    </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div>                                                                                       
                       </div>
                    </div>
                   <hr>
                </div>
              </div>
                <!--Developer: pOSTE DIV-->    
            
              
              <div class="col-sm-9">
                                      <div name="review" style="">Developer: <hr>
                                                      <div class="container">
                                                            <div class="row">
                                                                  <div class="col-sm-5">
                                                                   
                                                                          <!-- Reviews Loop Begins -->
                                                                          <?php   $count=0;
                                                                                  foreach ($reviews as $review) 
                                                                                  if( $review['stage'] == "Developer:"){
                                                                                  
                                                                                  if($count==3) break;
                                                                          ?> 
                                                                                    <div class="col-lg-8 review">
                                                                                        <input type='file' id="imgInp" onchange="readURL(this);" />
        <img id="blah" src="#" alt="your image" />
                                                                                      <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                                                                      <label class="inline">Rating :</label>
                                                                          <?php       for($i=0; $i<$review['stage']; $i++)
                                                                                      {
                                                                          ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                                                          <?php       }
                                                                          ?>          <br>
                                                                                      <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                                                                      <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                                                                      <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                                                                    </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div>                                                                                       
                       </div>
                    </div>
                   <hr>
                </div>
              </div>
                <!--, Entrepreneur: pOSTE DIV-->
            
              
              <div class="col-sm-9">
                                      <div name="review" style="">Entrepreneur: <hr>
                                                      <div class="container">
                                                            <div class="row">
                                                                  <div class="col-sm-5">
                                                                   
                                                                          <!-- Reviews Loop Begins -->
                                                                          <?php   $count=0;
                                                                                  foreach ($reviews as $review) 
                                                                                  if( $review['stage'] == "Entrepreneur:"){
                                                                                  
                                                                                  if($count==3) break;
                                                                          ?> 
                                                                                    <div class="col-lg-8 review">
                                                                                        <input type='file' id="imgInp" onchange="readURL(this);" />
        <img id="blah" src="#" alt="your image" />
                                                                                      <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                                                                      <label class="inline">Rating :</label>
                                                                          <?php       for($i=0; $i<$review['stage']; $i++)
                                                                                      {
                                                                          ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                                                          <?php       }
                                                                          ?>          <br>
                                                                                      <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                                                                      <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                                                                      <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                                                                    </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div>                                                                                       
                       </div>
                    </div>
                   <hr>
                </div>
              </div>
            </div>
           
<div>
    <div class="col-lg-9">
<label>
My Review

</label>
 <form action="createReview" method="post">
      <div class="form-group">
                                                                                        <label for="title">Topic:</label>
                                                                                        <input type="text" name="title" class="form-control" id="title" placeholder="Book Title">
                                                                                      </div>
                                                                                      <div class="form-group">
                                                                                        <label for="author">Author:</label>
                                                                                        <input type="text" name="author" class="form-control" id="author" placeholder="Author Name">
                                                                                      </div>
                                                                                      <div class="form-group">
                                                                                        <label for="review">Review:</label>
                                                                                        <textarea class="form-control" rows="6" name="review" id="review">Write your review...</textarea>
                                                                                      </div>
                                                                                      <div class="form-group">
                                                                                        <label for="rating">Rating:</label>
                                                                                        <select class="form-control" name="rating" id="rating">
                                                                                          <option value="1">1</option>
                                                                                          <option value="2">2</option>
                                                                                          <option value="3">3</option>
                                                                                          <option value="4">4</option>
                                                                                          <option value="5">5</option>
                                                                                        </select>
                                                                                      </div>
                                                                                      <div class="form-group">
                                                                                        <label for="stage">Stage:</label>




                                                                                        <select class="form-control" name="stage" id="stage">
                                                                                          <option value="Company_ID">Company ID</option>
                                                                                           
                                                                                            <option value="Sales:"> 
Sales:</option>
                                                                                             <option value="Digital_Marketing:">
Digital Marketing:
</option>
                                                                                             <option value="Web_Design:">Web Design:
</option>
                                                                                              <option value="Video_Production:">Video Production:
</option>
                                                                                              <option value="Developer:">Developer:</option>
                                                                                              <option value="Entrepreneur:">
Entrepreneur:</option>
                                                                                          <option value="Course_Request">Course_Request</option>
                                                                                          
                                                                                        </select>
                                                                                      </div>
                                                                                      <input type="hidden" name="user_id" value="<?= $this->session->userdata('user_id'); ?>">
                                                                                      <input type="submit" class="btn btn-info pull-right" value="Add My Review">
                                                                                    </form>
                                                                                    <br>
                                                                                    <hr>
                                                                                      <h3>Create A Business Case</h3>
                                                                                      <h4>Ask what the client is useing on prem in there datacenter. How many severs how many client facing applications. Spesific specs. Input this infomation in the TCO Calculater bellow.</h4>
                                                                               
                                                                                  
  

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <div class="modal-body">
          <p><iframe src="https://awstcocalculator.com/" style="border:1px #FFFFFF none;" name="myiFrame" scrolling="yes" frameborder="0" marginheight="0px" marginwidth="0px" height="600px" width="860px"></iframe></p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
          
<hr>
                             <h3>Create Course</h3>
                                                                            <div>
                                                                                <p>
                                                                                
  <h3>Add a new course&lt;/h3>
  <form action='<?php echo base_url('/courses/add'); ?>' method='post'>
    <label>Name:
      <input type='text' name='name' />
    </label>
    <br />
    <label>Description:
      <textarea name='description'></textarea>
    </label>
    <br />
    <input type='submit' value='Add' />
  </form>

<?php echo $this->session->flashdata('message'); ?>

  <h3>Courses</h3>
  <table>
    <thead>
      <tr>
        <th>Course Name</th>
        <th>Description</th>
        <th>Date Added</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
<?php
      //var_dump($courses);

      foreach ($courses as $course_data) 
      {
        $date_added = date('F d, Y', strtotime($course_data['created_at']));
        
        echo "<tr>
            <td>". $course_data['name'] . "</td>
            <td>". $course_data['description'] . "</td>
            <td>". $date_added . "</td>
            <td><a href= 'courses/destroy/". $course_data['id']. "'>Remove</a></td>
        </tr>";
      }
?>
    </tbody>
  </table>
                                                                               
                                                                            </div>
                                                                            </div>
                                                                            </div>
                                                                            </div>
                                                                            
   
    <!--RoadMap p3-->
    <div class="tabs-panel" id="panel3">
    <div class="row">
    <div class="media-object stack-for-small">
        
    
        <div name="review" style="">2010-2012<hr>
                                                      <div class="container">
                                                            <div class="row">
                                                                  <div class="col-sm-9">
                                                                   
                                                                          <!-- Reviews Loop Begins -->
                                                                          <?php   $count=0;
                                                                                  foreach ($reviews as $review) 
                                                                                  if( $review['stage'] == "Pivot_Table:"){
                                                                                  
                                                                                  if($count==3) break;
                                                                          ?> 
                                                                                    <div class="col-lg-8 review">
                                                                                        <input type='file' id="imgInp" onchange="readURL(this);" />
        <img id="blah" src="#" alt="your image" />
                                                                                      <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                                                                      <label class="inline">Rating :</label>
                                                                          <?php       for($i=0; $i<$review['stage']; $i++)
                                                                                      {
                                                                          ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                                                          <?php       }
                                                                          ?>          <br>
                                                                                      <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                                                                      <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                                                                      <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                                                                    </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div>                                                                                       
                       </div>
                    </div>
                   <hr>
             
       
                                                                   
                                                                             <div class="col-sm-9">
                                      <div name="review" style="">2012-2014<hr>
                                                      <div class="container">
                                                            <div class="row">
                                                                  <div class="col-sm-5">
                                                                   
                                                                          <!-- Reviews Loop Begins -->
                                                                          <?php   $count=0;
                                                                                  foreach ($reviews as $review) 
                                                                                  if( $review['stage'] == "Charts:"){
                                                                                  
                                                                                  if($count==3) break;
                                                                          ?> 
                                                                                    <div class="col-lg-8 review">
                                                                                        <input type='file' id="imgInp" onchange="readURL(this);" />
        <img id="blah" src="#" alt="your image" />
                                                                                      <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                                                                      <label class="inline">Rating :</label>
                                                                          <?php       for($i=0; $i<$review['stage']; $i++)
                                                                                      {
                                                                          ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                                                          <?php       }
                                                                          ?>          <br>
                                                                                      <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                                                                      <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                                                                      <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                                                                    </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div>                                                                                       
                       </div>
                    </div>
                   <hr>
                </div>
              </div> 
            
                <!--VLookup: pOSTE DIV-->
                <div class="col-sm-9">
                                      <div name="review" style="">2014-2016<hr>
                                                      <div class="container">
                                                            <div class="row">
                                                                  <div class="col-sm-5">
                                                                   
                                                                          <!-- Reviews Loop Begins -->
                                                                          <?php   $count=0;
                                                                                  foreach ($reviews as $review) 
                                                                                  if( $review['stage'] == "VLookup:"){
                                                                                  
                                                                                  if($count==3) break;
                                                                          ?> 
                                                                                    <div class="col-lg-8 review">
                                                                                        <input type='file' id="imgInp" onchange="readURL(this);" />
        <img id="blah" src="#" alt="your image" />
                                                                                      <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                                                                      <label class="inline">Rating :</label>
                                                                          <?php       for($i=0; $i<$review['stage']; $i++)
                                                                                      {
                                                                          ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                                                          <?php       }
                                                                          ?>          <br>
                                                                                      <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                                                                      <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                                                                      <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                                                                    </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div>                                                                                       
                       </div>
                    </div>
                   <hr>
                </div>
              </div> 
            </div>
           
                <!--Liner regration: pOSTE DIV-->
                <div class="col-sm-9">
                                      <div name="review" style="">2016-2017<hr>
                                                      <div class="container">
                                                            <div class="row">
                                                                  <div class="col-sm-5">
                                                                   
                                                                          <!-- Reviews Loop Begins -->
                                                                          <?php   $count=0;
                                                                                  foreach ($reviews as $review) 
                                                                                  if( $review['stage'] == "lerner registration:"){
                                                                                  
                                                                                  if($count==3) break;
                                                                          ?> 
                                                                                    <div class="col-lg-8 review">
                                                                                        <input type='file' id="imgInp" onchange="readURL(this);" />
        <img id="blah" src="#" alt="your image" />
                                                                                      <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                                                                      <label class="inline">Rating :</label>
                                                                          <?php       for($i=0; $i<$review['stage']; $i++)
                                                                                      {
                                                                          ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                                                          <?php       }
                                                                          ?>          <br>
                                                                                      <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                                                                      <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                                                                      <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                                                                    </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  
                        </div>                                                                                       
                       </div>
                    </div>
                   <hr>
                </div>
              </div> 
            
           
<label>
My Review

</label>
 <form action="createReview" method="post">
      <div class="form-group">
                                                                                        <label for="title">Book Title:</label>
                                                                                        <input type="text" name="title" class="form-control" id="title" placeholder="Book Title">
                                                                                      </div>
                                                                                      <div class="form-group">
                                                                                        <label for="author">Author:</label>
                                                                                        <input type="text" name="author" class="form-control" id="author" placeholder="Author Name">
                                                                                      </div>
                                                                                      <div class="form-group">
                                                                                        <label for="review">Review:</label>
                                                                                        <textarea class="form-control" rows="6" name="review" id="review">Write your review...</textarea>
                                                                                      </div>
                                                                                      <div class="form-group">
                                                                                        <label for="rating">Rating:</label>
                                                                                        <select class="form-control" name="rating" id="rating">
                                                                                          <option value="1">1</option>
                                                                                          <option value="2">2</option>
                                                                                          <option value="3">3</option>
                                                                                          <option value="4">4</option>
                                                                                          <option value="5">5</option>
                                                                                        </select>
                                                                                      </div>
                                                                                      <div class="form-group">
                                                                                        <label for="stage">Stage:</label>




                                                                                        <select class="form-control" name="stage" id="stage">
                                                                                          <option value="The_Idea">Company Infomation</option>
                                                                                           
                                                                                            <option value="CXO:"> CXO:</option>
                                                                                             <option value="Managers:">Managers:</option>
                                                                                             <option value="Sales Team:">Sales Team:</option>
                                                                                              <option value="Development Team:">Development Team:</option>
                                                                                              <option value="Migratition Team:">Migratition Team:</option>
                                                                                              <option value="Solution Achetecture Team:">Solution Achetecture Team:</option>
                                                                                          
                                                                                          <option value="DataCenters">DataCenters</option>
                                                                                          <option value="Cloud Stratagy">Cloud Stratagy</option>
                                                                                          <option value="Storage">Storage</option>
                                                                                          <option value="Dev/Test">Dev/Test</option>
                                                                                          <option value="Big Data">Big Data</option>
                                                                                          <option value="Budget:">Budget</option>
                                                                                          <option value="Authority:">Authority:</option>
                                                                                          <option value="Need:">Need:</option>
                                                                                          <option value="Pivot_Table:">Pivot_Table:</option>
                                                                                           <option value="Charts:">Charts:</option>
                                                                                            <option value="Vlookup:">VLookup:</option>
                                                                                             <option value="lerner registration:">lerner registration:</option>
                                                                                              
                                                                                          
                                                                                          <option value="Course_Request">Course_Request</option>
                                                                                          
                                                                                        </select>
                                                                                      </div>
                                                                                      <input type="hidden" name="user_id" value="<?= $this->session->userdata('user_id'); ?>">
                                                                                      <input type="submit" class="btn btn-info pull-right" value="Add My Review">
                                                                                    </form>
                                                                                    <br>
                                                                                    <hr>
                                                                                      <h3>Create A Business Case</h3>
                                                                                      <h4>Ask what the client is useing on prem in there datacenter. How many severs how many client facing applications. Spesific specs. Input this infomation in the TCO Calculater bellow.</h4>
                                                                               
                                                                                  
  <h2>TCO</h2>
  <!-- Trigger the modal with a button -->
  
  <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">TCO</button>

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <div class="modal-body">
          <p><iframe src="https://awstcocalculator.com/" style="border:1px #FFFFFF none;" name="myiFrame" scrolling="yes" frameborder="0" marginheight="0px" marginwidth="0px" height="600px" width="860px"></iframe></p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
          
<hr>
                             <h3>Create Course</h3>
                                                                            <div>
                                                                                <p>
                                                                                
  <h3>Add a new course&lt;/h3>
  <form action='<?php echo base_url('/courses/add'); ?>' method='post'>
    <label>Name:
      <input type='text' name='name' />
    </label>
    <br />
    <label>Description:
      <textarea name='description'></textarea>
    </label>
    <br />
    <input type='submit' value='Add' />
  </form>

<?php echo $this->session->flashdata('message'); ?>

  <h3>Courses</h3>
  <table>
    <thead>
      <tr>
        <th>Course Name</th>
        <th>Description</th>
        <th>Date Added</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
<?php
      //var_dump($courses);

      foreach ($courses as $course_data) 
      {
        $date_added = date('F d, Y', strtotime($course_data['created_at']));
        
        echo "<tr>
            <td>". $course_data['name'] . "</td>
            <td>". $course_data['description'] . "</td>
            <td>". $date_added . "</td>
            <td><a href= 'courses/destroy/". $course_data['id']. "'>Remove</a></td>
        </tr>";
      }
?>
    </tbody>
  </table>
                                                                               
                                                                            </div> </div></div></div></div>
                                                                            
                                                                           
  
</div>
 

    <!-- Bootstrap Core JavaScript -->
    <script src="/js/bootstrap.min.js"></script>




<script>function inject(){function a(){function a(a){parent.postMessage({type:"blockedWindow",args:JSON.stringify(a)},l)}function b(a){var b=a[1];return null!=b&&["_blank","_parent","_self","_top"].indexOf(b)<0?b:null}function e(a,b){var c;for(c in a)try{void 0===b[c]&&(b[c]=a[c])}catch(d){}return b}var g=arguments,h=!0,j=null,k=null;if(null!=window.event&&(k=window.event.currentTarget),null==k){for(var m=g.callee;null!=m.arguments&&null!=m.arguments.callee.caller;)m=m.arguments.callee.caller;null!=m.arguments&&m.arguments.length>0&&null!=m.arguments[0].currentTarget&&(k=m.arguments[0].currentTarget)}null!=k&&(k instanceof Window||k===document||null!=k.URL&&null!=k.body||null!=k.nodeName&&("body"==k.nodeName.toLowerCase()||"#document"==k.nodeName.toLowerCase()))?(window.pbreason="Blocked a new window opened with URL: "+g[0]+" because it was triggered by the "+k.nodeName+" element",h=!1):h=!0;document.webkitFullscreenElement||document.mozFullscreenElement||document.fullscreenElement;if(((new Date).getTime()-d<1e3||isNaN(d)&&c())&&(window.pbreason="Blocked a new window opened with URL: "+g[0]+" because a full screen was just initiated while opening this url.",document.exitFullscreen?document.exitFullscreen():document.mozCancelFullScreen?document.mozCancelFullScreen():document.webkitCancelFullScreen&&document.webkitCancelFullScreen(),h=!1),1==h){j=f.apply(this,g);var n=b(g);if(null!=n&&(i[n]=j),j!==window){var o=(new Date).getTime(),p=j.blur;j.blur=function(){(new Date).getTime()-o<1e3?(window.pbreason="Blocked a new window opened with URL: "+g[0]+" because a it was blured",j.close(),a(g)):p()}}}else{var q={href:g[0]};q.replace=function(a){q.href=a},j={close:function(){return!0},test:function(){return!0},blur:function(){return!0},focus:function(){return!0},showModelessDialog:function(){return!0},showModalDialog:function(){return!0},prompt:function(){return!0},confirm:function(){return!0},alert:function(){return!0},moveTo:function(){return!0},moveBy:function(){return!0},resizeTo:function(){return!0},resizeBy:function(){return!0},scrollBy:function(){return!0},scrollTo:function(){return!0},getSelection:function(){return!0},onunload:function(){return!0},print:function(){return!0},open:function(){return this},opener:window,closed:!1,innerHeight:480,innerWidth:640,name:g[1],location:q,document:{location:q}},e(window,j),j.window=j;var n=b(g);if(null!=n)try{i[n].close()}catch(r){}setTimeout(function(){var b;b=j.location instanceof Object?j.document.location instanceof Object?null!=q.href?q.href:g[0]:j.document.location:j.location,g[0]=b,a(g)},100)}return j}function b(a){d=a?(new Date).getTime():0/0}function c(){return document.fullScreenElement&&null!==document.fullScreenElement||null!=document.mozFullscreenElement||null!=document.webkitFullscreenElement}var d,e="originalOpenFunction",f=window.open,g=document.createElement,h=document.createEvent,i={},j=0,k=null,l=window.location!=window.parent.location?document.referrer:document.location;window[e]=window.open,window.open=function(){try{return a.apply(this,arguments)}catch(b){return null}},document.createElement=function(){var a=g.apply(document,arguments);if("a"==arguments[0]||"A"==arguments[0]){j=(new Date).getTime();var b=a.dispatchEvent;a.dispatchEvent=function(c){return null!=c.type&&"click"==(""+c.type).toLocaleLowerCase()?(window.pbreason="blocked due to an explicit dispatchEvent event with type 'click' on an 'a' tag",parent.postMessage({type:"blockedWindow",args:JSON.stringify({0:a.href})},l),!0):b(c)},k=a}return a},document.createEvent=function(){try{return arguments[0].toLowerCase().indexOf("mouse")>=0&&(new Date).getTime()-j<=50?(window.pbreason="Blocked because 'a' element was recently created and "+arguments[0]+" event was created shortly after",arguments[0]=k.href,parent.postMessage({type:"blockedWindow",args:JSON.stringify({0:k.href})},l),null):h.apply(document,arguments)}catch(a){}},document.addEventListener("fullscreenchange",function(){b(document.fullscreen)},!1),document.addEventListener("mozfullscreenchange",function(){b(document.mozFullScreen)},!1),document.addEventListener("webkitfullscreenchange",function(){b(document.webkitIsFullScreen)},!1)} inject()</script>
                                                                                      
               

<script src="http://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.js"></script>
<script>
      $(document).foundation();
    </script>
    <script>
$("input").change(function(e) {

    for (var i = 0; i < e.originalEvent.srcElement.files.length; i++) {
        
        var file = e.originalEvent.srcElement.files[i];
        
        var img = document.createElement("img");
        var reader = new FileReader();
        reader.onloadend = function() {
             img.src = reader.result;
        }
        reader.readAsDataURL(file);
        $("input").after(img);
    }
});
    </script>
    <script>
function myFunction() {
   if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#blah').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
    }
}
</script>
<script>
$(document).on('ready', function() {
    $("#input-24").fileinput({
        initialPreview: [
            'http://upload.wikimedia.org/wikipedia/commons/thumb/e/e1/FullMoon2010.jpg/631px-FullMoon2010.jpg',
            'http://upload.wikimedia.org/wikipedia/commons/thumb/6/6f/Earth_Eastern_Hemisphere.jpg/600px-Earth_Eastern_Hemisphere.jpg'
        ],
        initialPreviewAsData: true,
        initialPreviewConfig: [
            {caption: "Moon.jpg", size: 930321, width: "120px", key: 1},
            {caption: "Earth.jpg", size: 1218822, width: "120px", key: 2}
        ],
        deleteUrl: "/site/file-delete",
        overwriteInitial: false,
        maxFileSize: 100,
        initialCaption: "The Moon and the Earth"
    });
});
</script>
</body>
</html>