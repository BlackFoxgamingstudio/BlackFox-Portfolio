// load http module, needed for running node web server
// load fs module, needed for reading and writing files 
var http = require('http');
var fs = require('fs');
// run the web server using http module
var server = http.createServer(function (request, response){
    // log the URL visited by the client
    console.log('client requested this URL: ', request.url);
    // check the url visited and load the corresponding file
    switch(request.url){
        case '/': 
            filename = 'index.html';
        break;
        case '/ninjas': 
            filename = 'ninjas.html'; 
        break;
        case '/dojos/new': 
            filename = 'dojos.html'; 
        break;
        default: 
            filename = null;
        break;
    }
    //load the file and render the page
    if(filename != null){
        fs.readFile(filename, 'utf8', function (errors, contents){
            response.writeHead(200, {'Content-Type': 'text/html'});
            response.write(contents);
            response.end();
        }); 
    }
    else {
        response.writeHead(404);
        response.end('File not found!!!');
    }
});
// set port where server needs to run
server.listen(6789);
console.log("Running in localhost at port 6789");