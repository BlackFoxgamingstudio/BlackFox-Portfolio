// load http module, needed for running node web server
// load fs module, needed for reading and writing files 
var http = require('http');
var fs = require('fs');
// run the web server using http module
server = http.createServer(function (request, response){
  // log the URL visited by the client
  console.log('Request', request.url);
  // check the url visited and load the corresponding file
  switch(request.url){
        case '/':
            filename = 'views/index.html';
        break;
        case '/cars/index.html':
            filename = 'views/cars.html'; 
        break;
        case '/cats/index.html': 
            filename = 'views/cats.html'; 
        break;
        case '/style.css': 
            filename = './styles/style.css'; 
        break;
        case '/images/cats_1.jpg': 
            filename = './images/cats_1.jpg'; 
        break;
        case '/images/cars_1.jpg': 
            filename = './images/cars_1.jpg'; 
        break;
        default: 
            filename = null;
        break;
    }
    //load the file and render the page
    if(filename != null){
        fs.readFile(filename, function (errors, contents){
            response.write(contents);
            response.end();
        }); 
    }
    else{
        response.writeHead(404);
        response.end('File not found!!!');
    }
});
server.listen(7707);
console.log("Running in localhost at port 7707");