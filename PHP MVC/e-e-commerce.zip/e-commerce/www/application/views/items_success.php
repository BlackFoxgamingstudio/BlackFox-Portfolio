<!DOCTYPE html>
<html lang='en'>
<head>
	<meta charset='utf-8'>
	<title>Items Home Page</title>
	<link rel="stylesheet" type="text/css" href="/assets/style_items.css">
</head>
<body>
	<div id='wrapper'>
		<h1 class='green'>Your purchase has been confirmed!</h1>
		<h2><a href='/users/logout'>Log Out</a></h2>
	</div>
</body>
</html>