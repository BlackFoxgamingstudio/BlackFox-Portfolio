<h1 class="page-header">My Profile</h1>
<div class="well col-md-6">
	<h3>Welcome <?php echo $current_user['user_level'];?> !!! <?php echo $current_user['user_name'];?> </h2>
    <h5>User Id : <?php echo $current_user['user_id'];?></h3>
</div>
 