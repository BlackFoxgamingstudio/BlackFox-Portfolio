 
<h1 class="page-header">Login</h1>

</div>
	<div class="row">
		<div class="col-md-5">
			<form action="/access/user_login" method="post">
				<div class="form-group">
					<label>Email</label>
					<input type="email" name="username" class="form-control" >
				</div>
				<div class="form-group">
					<label>Password</label>
					<input type="password" name="password" class="form-control">
				</div>
				<input type="submit" name="form_action" value="Login" class="btn btn-primary">
			</form>
	    </div>
	  </div>
	  <div class="row">
		<div class="col-md-5">
			<p>Dont have and account ?<a href="register">Register here</a></p>
		</div>
	</div>
	
</body>
</html>

	
  
 



