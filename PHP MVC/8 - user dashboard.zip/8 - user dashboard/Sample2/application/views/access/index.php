 
	<div class="jumbotron">
		<h2>Welcome to the Test</h2>
		<p>We are going to build a cool application using MVC framework..
			Lorem Ipsum is simply dummy text of 
			the printing and typesetting industry. Lorem Ipsum has been the 
			industry's standard dummy text ever since the 1500s, when an unknown 
			printer took a galley of type and scrambled it t</p>
	</div>
	<div class="row">
		<div class="col-md-4">
			<h3>Manage Users</h3>
			<p>Users to add, edit , remove users of the application.
			Lorem Ipsum is simply dummy text of the printing and typesetting 
			industry. Lorem Ipsum has been the industry's standard dummy text ever 
			since the 1500s, when an unknown printer took a galley of type and 
			scrambled it t</p>
		</div>
		<div class="col-md-4">
			<h3>Leave message</h3>
			<p>Users will a message to other users using this application.
			Lorem Ipsum is simply dummy text of the printing and typesetting 
			industry. Lorem Ipsum has been the industry's standard dummy text ever
			 since the 1500s, when an unknown printer took a galley of type and 
			 scrambled it t</p>
		</div>
		<div class="col-md-4">
			<h3>Edit User Information</h3>
			<p>Admins will be able to edit other users information.
			Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
			Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
			 when an unknown printer took a galley of type and scrambled it t</p>
		</div>
	</div>
	 <?php $this->load->view('partials/footer'); ?> 
</body>