 
 <div class="row">
 		<footer>
		<p class="text-center">Copyright</p> 
	</footer>
 </div>
</body>
</html>

  
	