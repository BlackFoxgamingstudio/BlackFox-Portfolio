<!DOCTYPE HTML>
<html lang="en-US">
	<head>
		<meta charset="UTF-8">
		<title>Home Page</title>
		<link rel="stylesheet" href="/assets/css/bootstrap.css">
		<link rel="stylesheet" href="/assets/css/tablesorter.css">
		<link rel="stylesheet" href="/assets/css/jquery-ui.css">
		<link rel="stylesheet" href="/assets/css/user_style.css">
		<script src="/assets/js/jquery-1.8.2.min.js"></script>
		<script src="/assets/js/bootstrap.min.js"></script>
		<script src="/assets/js/jquery.tablesorter.min.js"></script>
		<script src="/assets/js/jquery-ui.js"></script>
	