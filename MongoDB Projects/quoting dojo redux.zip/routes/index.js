module.exports = function Route(app, Qoutes){
	// errors_array 
	var errors_array = [];
	// root route
	app.get('/', function(req, res) {
	    Qoutes.find({}, function(err, qoutes) {
	    res.render('index', {errors: errors_array});
	    })
	})
	// route to main
	app.get('/main', function(req, res) {
	  	  Qoutes.find({}, function(err, qoutes) {
		   	res.render('main',{qoutes: qoutes} );
	    })
	})
	// route to add qoutes
	app.post('/main', function(req, res) {
	  qoutes = new Qoutes({name: req.body.name, qoutes: req.body.qoutes});
	  qoutes.save(function(err) {
	    errors_array = [];
	    if(err) {
	    	for(var x in err.errors)
	    	{ 
	        	// push the errors into the errors_array 
	    		errors_array.push(err.errors[x].message);
	    	}
	    	res.redirect('/');
	    } else { 
	      res.redirect('/main');
	    }
	  })
	})
};