# Book Review App (MVC CodeIgniter)
Application built in MVC CodeIgniter, which allows users to add books, create reviews and view other users' reviews

This app was built as a practice run for the Red Belt qualifying examination. It was built in 5 1/2 hours.