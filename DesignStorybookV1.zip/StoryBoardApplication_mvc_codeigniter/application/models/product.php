<?php
class Product extends DataMapper {
	 var $has_one = array('manufacturer');

	public function __construct($id = null)
	{
		parent::__construct($id);
	}
	
	public function p_save($post_data)
	{
		$data = elements(array('manufacturer_id', 'name', 'price', 'description'), $post_data, NULL);
		
		$this->manufacturer_id = $data['manufacturer_id'];
		$this->name = $data['name'];
		$this->price = $data['price'];
		$this->description = $data['description'];

		return $this->save();
	}
}