<?php 
  $this->load->view('partials/head');
?>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Dreamlancer 0-100 Design</title>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
  <script src="//code.jquery.com/jquery-1.10.2.js"></script>
 <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
  <link rel="stylesheet" href="/style.css">
  <script>
  $(function() {
    $( "#tabs" ).tabs();
  });
  </script>
<script>
  $(function() {
    $( "#accordion" ).accordion();
  });
  </script>
  <script>
  $(function() {
    $( "#accordion2" ).accordion();
  });
  </script>
  <script>
  $(function() {
    $( "#accordion3" ).accordion();
  });
  </script>
  <script>
  $(function() {
    $( "#accordion4" ).accordion();
  });
  </script>
  <script>
  $(function() {
    $( "#accordion5" ).accordion();
  });
  </script>
  <script>
  $(function() {
    $( "#accordion6" ).accordion();
  });
  </script>
  <script>
  $(function() {
    $( "#accordion7" ).accordion();
  });
  </script>
  <script>
  $(function() {
    $( "#accordion8" ).accordion();
  });
  </script>
  <script>
  $(function() {
    $( "#accordion9" ).accordion();
  });
  </script>
  <script>
  $(function() {
    $( "#accordion10" ).accordion();
  });
  </script>
<script>
  $(function() {
    $( "#accordion42" ).accordion();
  });
  </script>
</head>
<body data-gr-c-s-loaded="true">
<?php 
  $this->load->view('partials/navbar');
  $this->load->view('partials/messages');
  
?>
<?php     
  if($this->session->userdata('name'))
  {
?>          
    <div class="container">
      <div class="row">
        <div class="col-lg-12">

          <h2>Welcome <?= $this->session->userdata('name'); ?></h2>
          <center><h1> Your DESIGN STAGE StoryBook</h1></center>
        </div>
      </div>
    </div>
<?php     }
?>
<div class="col-lg-9">


 

 
 
        <div id="tabs">
                            <ul>
                              <li><a href="#tabs-0">The Idea</a></li>
                              <li><a href="#tabs-1">Script </a></li>
                              <li><a href="#tabs-2">Thumbnail</a></li>
                              <li><a href="#tabs-3">Rough Draft</a></li>
                              <li><a href="#tabs-4">Refine Draft</a></li>
                              <li><a href="#tabs-5">Storyboard</a></li>
                              <li><a href="#tabs-6">modeling</a></li>
                              <li><a href="#tabs-7">Texture</a></li>
                              <li><a href="#tabs-8">Game design</a></li>
                              <li><a href="#tabs-9">game Programing</a></li>
                              <li><a href="#tabs-42">Marketplace</a></li>
                            </ul>
                            <div id="tabs-0">
                              <div class="row">

                                  <div class="col-sm-4">
                                      <div name="review" style="">Your IDeas Will Be posted HERE. Notes and Comments will be add by dreamlancers:).
                                                      <div class="container">
                                                            <div class="row">
                                                                  <div class="col-sm-5">
                                                                    <h3>Recent Idea Reviews:</h3>
                                                                          <!-- Reviews Loop Begins -->
                                                                          <?php   $count=0;
                                                                                  foreach ($reviews as $review) 
                                                                                  if( $review['stage'] == "The_Idea"){
                                                                                  
                                                                                  if($count==3) break;
                                                                          ?> 
                                                                                    <div class="col-lg-8 review">
                                                                                      <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                                                                      <label class="inline">Rating :</label>
                                                                          <?php       for($i=0; $i<$review['stage']; $i++)
                                                                                      {
                                                                          ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                                                          <?php       }
                                                                          ?>          <br>
                                                                                      <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                                                                      <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                                                                      <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                                                                    </div>

                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                          ?>
                                                                  </div>

                                                                   
                       <div class="row" id="script">
                                                                  <div class="col-sm-5">
                                                                    <h3>Recent script Reviews:</h3>
                                                                  <!-- Reviews Loop Begins -->
                                                                          <?php   $count=0;
                                                                                  foreach ($reviews as $review) 
                                                                                  if( $review['stage'] == "Scipt"){
                                                                                  
                                                                                  {
                                                                                    

                                                                                  if($count==3) break;
                                                                          ?> 
                                                                                    <div class="col-lg-8 review">
                                                                                      <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                                                                      <label class="inline">Rating :</label>
                                                                          <?php       for($i=0; $i<$review['stage']; $i++)
                                                                                      {
                                                                          ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                                                          <?php       }
                                                                          }
                                                                          ?>          <br>
                                                                                      <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                                                                      <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                                                                      <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                                                                    </div>
}
                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                                  else{
                                                                                    echo "Add A Script Next";
                                                                                }
                                                                          ?>

                                                                  </div>
                        </div>                                                                                       
                       </div>
                    </div>
                   <hr>
                </div>
              </div> 
            </div>
           </div>

           <div id="tabs-42"> 
                            <div class="row" id="Marketplace">

    <div class="col-md-12" style="margin-top: 125px;">

        <div class="row">

            <div class="col-md-2">
                <p class="lead">DreamLancer CLoud Classes</p>
                <div class="list-group">
                    <a href="#" class="list-group-item">Dev Test</a>
                    <a href="/MicrosoftWorkloads.html" class="list-group-item">Microsoft Workloads</a>
                    <a href="/Amazon Partner Network" class="list-group-item">Amazon Partner Network</a>
                    <a href="/VPC and DR" class="list-group-item">VPC and DR</a>
                    <a href="/Storage" class="list-group-item">Storage</a>
                    <div class="row" id="script">
                              <div class="col-sm-12">
                                <h3>Recent Course Request:</h3>
                              <!-- Reviews Loop Begins -->
                                      <?php   $count=0;
                                              foreach ($reviews as $review) 
                                              if( $review['stage'] == "Course_Request"){
                                              
                                              {
                                                

                                              if($count==3) break;
                                      ?> 
                                                <div class="col-lg-8 review">
                                                  <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                                  <label class="inline">Rating :</label>
                                      <?php       for($i=0; $i<$review['stage']; $i++)
                                                  {
                                      ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                      <?php       }
                                      }
                                      ?>          <br>
                                                  <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                                  <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                                  <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                                </div>
}
                                      <!-- Reviews Loop Ends -->
                                      <?php     $count++;
                                              }
                                              else{
                                                echo "Add A Script Next";
                                            }
                                      ?>

                                                                  </div>
                        </div>  
                </div>
            </div>

            <div class="col-md-9">

                <div class="row carousel-holder">

                    <div class="col-md-12">
                        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                            <ol class="carousel-indicators">
                                <li data-target="#carousel-example-generic" data-slide-to="0" class=""></li>
                                <li data-target="#carousel-example-generic" data-slide-to="1" class=""></li>
                                <li data-target="#carousel-example-generic" data-slide-to="2" class="active"></li>
                                <li data-target="#carousel-example-generic" data-slide-to="3" class=""></li>
                            </ol>
                            <div class="carousel-inner">
                                <div class="item">
                                 <center><img src="https://docs.google.com/drawings/d/17LJPIUR0IFQ66U9vPa7yTVo-QKKeNk4VwNw5O3hJesI/pub?w=810&amp;h=480"><center>
                                  </div>
                                <div class="item">
                                     <center><img src="https://docs.google.com/drawings/d/17LJPIUR0IFQ66U9vPa7yTVo-QKKeNk4VwNw5O3hJesI/pub?w=810&amp;h=480"><center>
                                </div>
                                <div class="item">
                                     <center><img src="https://docs.google.com/drawings/d/17LJPIUR0IFQ66U9vPa7yTVo-QKKeNk4VwNw5O3hJesI/pub?w=810&amp;h=480"><center>
                                </div>
                                 <center><img src="https://docs.google.com/drawings/d/17LJPIUR0IFQ66U9vPa7yTVo-QKKeNk4VwNw5O3hJesI/pub?w=810&amp;h=480"><center>
                                </div>
                            </div>
                            <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                                <span class="glyphicon glyphicon-chevron-left"></span>
                            </a>
                            <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
                                <span class="glyphicon glyphicon-chevron-right"></span>
                            </a>
                            <div class="caption-full">
                        <h4 class="pull-right">$24.99</h4>
                        <h4><a href="#">Dev/Test Workload</a>
                        </h4>
                      
                        <p>Running development and test workloads on Amazon Web Services enables you to remove hardware-based resource constraints to quickly create developer environments and expand your testing machine fleet. You get instant access to machines that you can configure any way you want and you only pay for what you use. This agility enables you to bring new developers on faster, try out configuration changes in parallel, and run as large a test pass as you like; all with the click of a mouse.</p>
                    </div>
                    <div class="ratings">
                        <p class="pull-right">3 reviews</p>
                        <p>
                            <span class="glyphicon glyphicon-star"></span>
                            <span class="glyphicon glyphicon-star"></span>
                            <span class="glyphicon glyphicon-star"></span>
                            <span class="glyphicon glyphicon-star"></span>
                            <span class="glyphicon glyphicon-star-empty"></span>
                            4.0 stars
                        </p>
                    </div>
                        </div>
                    </div>


                <div class="row">

                    <div class="col-sm-4 col-lg-4 col-md-4">
                        <div class="thumbnail">
                            <iframe src="https://drive.google.com/file/d/0B-mdD0nj4WKkeDhFOEgyM0lKVlk/preview" width="260" height="150"></iframe>
                            <div class="caption">
                                <h4 class="pull-right">$224.99</h4>
                                <h4><a href="salesclass.html">CodeCommit</a>
                                </h4>
                                <p>AWS CodeCommit is a fully-managed source control service that makes it easy for companies to host secure and highly scalable private Git repositories. CodeCommit eliminates the need to operate your own source control system or worry about scaling its infrastructure. You can use CodeCommit to securely store anything from source code to binaries, and it works seamlessly with your existing Git tools.</p>
                            </div>
                            <div class="ratings">
                                <p class="pull-right">15 reviews</p>
                                <p>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-4 col-lg-4 col-md-4">
                        <div class="thumbnail">
                            <iframe src="https://drive.google.com/file/d/0B-mdD0nj4WKkeDhFOEgyM0lKVlk/preview" width="260" height="150"></iframe>
                            <div class="caption">
                                <h4 class="pull-right">$264.99</h4>
                                <h4><a href="designclass.html">Code Pipeline</a>
                                </h4>
                                <p>AWS CodePipeline is a continuous delivery service for fast and reliable application updates. CodePipeline builds, tests, and deploys your code every time there is a code change, based on the release process models you define. This enables you to rapidly and reliably deliver features and updates. You can easily build out an end-to-end solution by using our pre-built plugins for popular third-party services like GitHub....</p>
                            </div>
                            <div class="ratings">
                                <p class="pull-right">12 reviews</p>
                                <p>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star-empty"></span>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-4 col-lg-4 col-md-4">
                        <div class="thumbnail">
                            <iframe src="https://drive.google.com/file/d/0B-mdD0nj4WKkeDhFOEgyM0lKVlk/preview" width="260" height="150"></iframe>
                            <div class="caption">
                                <h4 class="pull-right">$474.99</h4>
                                <h4><a href="designclass.html">Code Deploy</a>
                                </h4>
                                <p>AWS CodeDeploy is a service that automates code deployments to any instance, including Amazon EC2 instances and instances running on-premises. AWS CodeDeploy makes it easier for you to rapidly release new features, helps you avoid downtime during application deployment, and handles the complexity of updating your applications. You can use AWS CodeDeploy to automate software deployments, eliminating the need for error-prone manual operations, and the service scales with your infrastructure so you can easily deploy to one instance or thousands.</p>
                            </div>
                            <div class="ratings">
                                <p class="pull-right">31 reviews</p>
                                <p>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star-empty"></span>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-4 col-lg-4 col-md-4">
                        <div class="thumbnail">
                            <iframe src="https://drive.google.com/file/d/0B-mdD0nj4WKkeDhFOEgyM0lKVlk/preview" width="260" height="150"></iframe>
                            <div class="caption">
                                <h4 class="pull-right">$584.99</h4>
                                <h4><a href="designclass.html">Lambda</a>
                                </h4>
                                <p>AWS Lambda lets you run code without provisioning or managing servers. You pay only for the compute time you consume - there is no charge when your code is not running. With Lambda, you can run code for virtually any type of application or backend service - all with zero administration. Just upload your code and Lambda takes care of everything required to run and scale your code with high availability. You can set up your code to automatically trigger from other AWS services or call it directly from any web or mobile app.</p>
                            </div>
                            <div class="ratings">
                                <p class="pull-right">6 reviews</p>
                                <p>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star-empty"></span>
                                    <span class="glyphicon glyphicon-star-empty"></span>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-4 col-lg-4 col-md-4">
                        <div class="thumbnail">
                           <iframe src="https://drive.google.com/file/d/0B-mdD0nj4WKkeDhFOEgyM0lKVlk/preview" width="260" height="150"></iframe>
                            <div class="caption">
                                <h4 class="pull-right">$2094.99</h4>
                                <h4><a href="designclass.html">DevOps</a>
                                </h4>
                                <p>As organizations create increasingly complex software applications, IT development teams evolved their software creation practices for more flexibility, moving from waterfall models to agile or lean development practices. This change also propagated to operation teams which blurred the lines between traditional Development and Ops teams.
<br>
Today, DevOps designates a set of tools, processes, best practices and corporate management guidelines that make an IT organization more agile and more efficient. While the software tools and practices promoted by DevOps practitioners are well understood, rigid infrastructures reduce the benefits and hinders the application of agile methods.
<br>
Amazon Web Services (AWS) provides a flexible environment that facilitated the successes of organizations like Netflix, Airbnb, Etsy, and many others that embraced DevOps. This series webinars deconstructs the elements of DevOps that made those success stories and provides best practices and practical examples on how to get started on DevOps with AWS, regardless of the size of your organization.</p>
                            </div>
                            <div class="ratings">
                                <p class="pull-right">18 reviews</p>
                                <p>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star-empty"></span>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-4 col-lg-4 col-md-4">
                        <h4><a href="#">Like this template?</a>
                        </h4>
                        <p>Our Sales Process Workflow:
                           <li>1.Lead Gen </li>
                           <li>2. Workload Call scripts</li>
                           <li>3. Demos </li> 
                           <hr> Assets:<hr>
                           <li><a target="_blank" href="http://maxoffsky.com/code-blog/laravel-shop-tutorial-1-building-a-review-system/">Dev/Test Whitepaper</a> </li> 
                           <li><a target="_blank" href="http://maxoffsky.com/code-blog/laravel-shop-tutorial-1-building-a-review-system/">DevOps WhitePaper</a>  </li> 
                           <li><a target="_blank" href="http://maxoffsky.com/code-blog/laravel-shop-tutorial-1-building-a-review-system/">CallScript</a></li> 
                           <li><a target="_blank" href="http://maxoffsky.com/code-blog/laravel-shop-tutorial-1-building-a-review-system/">FactSheet</a> </li> 
                           <li><a target="_blank" href="http://maxoffsky.com/code-blog/laravel-shop-tutorial-1-building-a-review-system/">CodeCommit Video</a> </li> 
                           <li><a target="_blank" href="http://maxoffsky.com/code-blog/laravel-shop-tutorial-1-building-a-review-system/">CodePipeline Video</a> </li> 
                           <li><a target="_blank" href="http://maxoffsky.com/code-blog/laravel-shop-tutorial-1-building-a-review-system/">CodeDeploy Video</a> </li> 
                           <br>
                        <a class="btn btn-primary" target="_blank" href="https://drive.google.com/open?id=17LJPIUR0IFQ66U9vPa7yTVo-QKKeNk4VwNw5O3hJesI">View Process</a>
                    </div>

                </div>

            </div>

        </div>
          
                   <hr>
               
              </div> 
            </div>
           </div>

         <div id="tabs-1">                       
          <div class="row" id="script">
                                                                  <div class="col-sm-5">
                                                                    <h3>Recent script Reviews:</h3>
                                                                  <!-- Reviews Loop Begins -->
                                                                          <?php   $count=0;
                                                                                  foreach ($reviews as $review) 
                                                                                  if( $review['stage'] == "Scipt"){
                                                                                  
                                                                                  {
                                                                                    

                                                                                  if($count==3) break;
                                                                          ?> 
                                                                                    <div class="col-lg-8 review">
                                                                                      <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                                                                      <label class="inline">Rating :</label>
                                                                          <?php       for($i=0; $i<$review['stage']; $i++)
                                                                                      {
                                                                          ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                                                          <?php       }
                                                                          }
                                                                          ?>          <br>
                                                                                      <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                                                                      <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                                                                      <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                                                                    </div>
}
                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                                  else{
                                                                                    echo "Add A Script Next";
                                                                                }
                                                                          ?>

                                                                  </div>

                                                                    

                                                                        
                       </div>
                    </div>
                   <div id="tabs-2">                       
          <div class="row" id="script">
                                                                  <div class="col-sm-5">
                                                                    <h3>Recent Thumbnail Reviews:</h3>
                                                                  <!-- Reviews Loop Begins -->
                                                                          <?php   $count=0;
                                                                                  foreach ($reviews as $review) 
                                                                                  if( $review['stage'] == "Thumbnail"){
                                                                                  
                                                                                  {
                                                                                    

                                                                                  if($count==3) break;
                                                                          ?> 
                                                                                    <div class="col-lg-8 review">
                                                                                      <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                                                                      <label class="inline">Rating :</label>
                                                                          <?php       for($i=0; $i<$review['stage']; $i++)
                                                                                      {
                                                                          ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                                                          <?php       }
                                                                          }
                                                                          ?>          <br>
                                                                                      <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                                                                      <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                                                                      <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                                                                    </div>
}
                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                                  else{
                                                                                    echo "Add A Script Next";
                                                                                }
                                                                          ?>

                                                                  </div>

                                                                    

                                                                        
                       </div>
                    </div>
                    <div id="tabs-3">                       
          <div class="row" id="script">
                                                                  <div class="col-sm-5">
                                                                    <h3>Recent Rough_Draft Reviews:</h3>
                                                                  <!-- Reviews Loop Begins -->
                                                                          <?php   $count=0;
                                                                                  foreach ($reviews as $review) 
                                                                                  if( $review['stage'] == "Rough_Draft"){
                                                                                  
                                                                                  {
                                                                                    

                                                                                  if($count==3) break;
                                                                          ?> 
                                                                                    <div class="col-lg-8 review">
                                                                                      <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                                                                      <label class="inline">Rating :</label>
                                                                          <?php       for($i=0; $i<$review['stage']; $i++)
                                                                                      {
                                                                          ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                                                          <?php       }
                                                                          }
                                                                          ?>          <br>
                                                                                      <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                                                                      <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                                                                      <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                                                                    </div>
}
                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                                  else{
                                                                                    echo "Add A Script Next";
                                                                                }
                                                                          ?>

                                                                  </div>

                                                                    

                                                                        
                       </div>
                    </div>
<div id="tabs-5">                       
          <div class="row" id="script">
                                                                  <div class="col-sm-5">
                                                                    <h3>Recent Refine Draft Reviews:</h3>
                                                                  <!-- Reviews Loop Begins -->
                                                                          <?php   $count=0;
                                                                                  foreach ($reviews as $review) 
                                                                                  if( $review['stage'] == "Refine_Draft"){
                                                                                  
                                                                                  {
                                                                                    

                                                                                  if($count==3) break;
                                                                          ?> 
                                                                                    <div class="col-lg-8 review">
                                                                                      <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                                                                      <label class="inline">Rating :</label>
                                                                          <?php       for($i=0; $i<$review['stage']; $i++)
                                                                                      {
                                                                          ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                                                          <?php       }
                                                                          }
                                                                          ?>          <br>
                                                                                      <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                                                                      <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                                                                      <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                                                                    </div>
}
                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                                  else{
                                                                                    echo "Add A Script Next";
                                                                                }
                                                                          ?>

                                                                  </div>

                                                                    

                                                                        
                       </div>
                    </div>
                    <div id="tabs-6">                       
          <div class="row" id="script">
                                                                  <div class="col-sm-5">
                                                                    <h3>Recent script Reviews:</h3>
                                                                  <!-- Reviews Loop Begins -->
                                                                          <?php   $count=0;
                                                                                  foreach ($reviews as $review) 
                                                                                  if( $review['stage'] == "Scipt"){
                                                                                  
                                                                                  {
                                                                                    

                                                                                  if($count==3) break;
                                                                          ?> 
                                                                                    <div class="col-lg-8 review">
                                                                                      <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                                                                      <label class="inline">Rating :</label>
                                                                          <?php       for($i=0; $i<$review['stage']; $i++)
                                                                                      {
                                                                          ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                                                          <?php       }
                                                                          }
                                                                          ?>          <br>
                                                                                      <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                                                                      <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                                                                      <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                                                                    </div>
}
                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                                  else{
                                                                                    echo "Add A Script Next";
                                                                                }
                                                                          ?>

                                                                  </div>

                                                                    

                                                                        
                       </div>
                    </div>
                    <div id="tabs-7">                       
          <div class="row" id="script">
                                                                  <div class="col-sm-5">
                                                                    <h3>Recent script Reviews:</h3>
                                                                  <!-- Reviews Loop Begins -->
                                                                          <?php   $count=0;
                                                                                  foreach ($reviews as $review) 
                                                                                  if( $review['stage'] == "Scipt"){
                                                                                  
                                                                                  {
                                                                                    

                                                                                  if($count==3) break;
                                                                          ?> 
                                                                                    <div class="col-lg-8 review">
                                                                                      <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                                                                                      <label class="inline">Rating :</label>
                                                                          <?php       for($i=0; $i<$review['stage']; $i++)
                                                                                      {
                                                                          ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                                                                          <?php       }
                                                                          }
                                                                          ?>          <br>
                                                                                      <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                                                                                      <p><i>Posted on <?= $review['created_at']; ?></i></p>
                                                                                      <p><i>Development Stage <?= $review['stage']; ?></i></p>
                                                                                    </div>
}
                                                                          <!-- Reviews Loop Ends -->
                                                                          <?php     $count++;
                                                                                  }
                                                                                  else{
                                                                                    echo "Add A Script Next";
                                                                                }
                                                                          ?>

                                                                  </div>

                                                                    

                                                                        
                       </div>
                    </div>
                   <hr>
                </div>
              </div> 
                <div class="col-sm-3 ">
                                                                      <div id="accordion">
                                                                            <h3>Create Idea</h3>
                                                                            <div>
                                                                                                                                              <div class="container">
                                                                                <div class="row">
                                                                                  <div class="col-sm-3">
                                                                                    <h3>Add a New Review</h3>
                                                                                    <form action="createReview" method="post">
                                                                                      <div class="form-group">
                                                                                        <label for="title">Book Title:</label>
                                                                                        <input type="text" name="title" class="form-control" id="title" placeholder="Book Title">
                                                                                      </div>
                                                                                      <div class="form-group">
                                                                                        <label for="author">Author:</label>
                                                                                        <input type="text" name="author" class="form-control" id="author" placeholder="Author Name">
                                                                                      </div>
                                                                                      <div class="form-group">
                                                                                        <label for="review">Review:</label>
                                                                                        <textarea class="form-control" rows="6" name="review" id="review">Write your review...</textarea>
                                                                                      </div>
                                                                                      <div class="form-group">
                                                                                        <label for="rating">Rating:</label>
                                                                                        <select class="form-control" name="rating" id="rating">
                                                                                          <option value="1">1</option>
                                                                                          <option value="2">2</option>
                                                                                          <option value="3">3</option>
                                                                                          <option value="4">4</option>
                                                                                          <option value="5">5</option>
                                                                                        </select>
                                                                                      </div>
                                                                                      <div class="form-group">
                                                                                        <label for="stage">Stage:</label>
                                                                                        <select class="form-control" name="stage" id="stage">
                                                                                          <option value="The_Idea">The Idea</option>
                                                                                          <option value="Scipt">Scipt</option>
                                                                                          <option value="Thumbnail">Thumbnail</option>
                                                                                          <option value="Rough_Draft">Rough Draft</option>
                                                                                          <option value="Refine_Draft">Refine Draft</option>
                                                                                          <option value="Course_Request">Course_Request</option>
                                                                                        </select>
                                                                                      </div>
                                                                                      <input type="hidden" name="user_id" value="<?= $this->session->userdata('user_id'); ?>">
                                                                                      <input type="submit" class="btn btn-info pull-right" value="Add My Review">
                                                                                    </form>
                                                                                  </div>
                                                                                </div>
                                                                                    </div>
                                                                          </div>
                                                                            <h3>Create Course</h3>
                                                                            <div>
                                                                                <p>
                                                                                
  <h3>Add a new course&lt;/h3>
  <form action='<?php echo base_url('/courses/add'); ?>' method='post'>
    <label>Name:
      <input type='text' name='name' />
    </label>
    <br />
    <label>Description:
      <textarea name='description'></textarea>
    </label>
    <br />
    <input type='submit' value='Add' />
  </form>

<?php echo $this->session->flashdata('message'); ?>

  <h3>Courses</h3>
  <table>
    <thead>
      <tr>
        <th>Course Name</th>
        <th>Description</th>
        <th>Date Added</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
<?php
      //var_dump($courses);

      foreach ($courses as $course_data) 
      {
        $date_added = date('F d, Y', strtotime($course_data['created_at']));
        
        echo "<tr>
            <td>". $course_data['name'] . "</td>
            <td>". $course_data['description'] . "</td>
            <td>". $date_added . "</td>
            <td><a href= 'courses/destroy/". $course_data['id']. "'>Remove</a></td>
        </tr>";
      }
?>
    </tbody>
  </table>
                                                                                </p>
                                                                            </div>
                                                                            <h3>Create New StoryBook</h3>
                                                                            <div>
                                                                              <p>
                                                                              Dear Stockholders,
                                                                              
                                                                              Education is the way to monitze the desire to own your own story. to choose to invest in your self. to build the skills need to build your dream and share it with the world. Create your idea from 0-100 and create your storybook for your new business and dream now!
                                                                              </p>
                                                                              <ul>
                                                                                <li>List item one</li>
                                                                                <li>List item two</li>
                                                                                <li>List item three</li>
                                                                              </ul>
                                                                            </div>
                                                                              <h3>Add Notes</h3>
                                                                                <div>
                                                                                    <p>
                                                                                    Dont have the skills to create a course. dont have the expeincer to land a job on are platform? no problem! earn tips adding helpful comments to each storyboard. storybook owner likes your ideas and find them helpful you will get tiped out for great insights!
                                                                                    </p>
                                                                                    <p>
                                                                                    Suspendisse eu nisl. Nullam ut libero. Integer dignissim consequat lectus.
                                                                                    Class aptent taciti sociosqu ad litora torquent per conubia nostra, per
                                                                                    inceptos himenaeos.
                                                                                    </p>
                                                                                </div>
                                                                          </div>
                                                                      </div>
           
 <div id="tabs-2">
                              <div class="row" id="script">
</div>

                                                                  
                  <div class="container">
                    <div class="row">
                      <div class="col-lg-6 col-md-12 col-sm-12">
                        <h3>Recent Book Reviews:</h3>
                <!-- Reviews Loop Begins -->
                <?php   $count=0;
                        foreach ($reviews as $review) 
                        {
                        if($count==3) break;
                ?> 
                          <div class="col-lg-10 review">
                            <a href="/book/<?= $review['book_id']; ?>"><h4><?= $review['title']; ?></h4></a>
                            <label class="inline">Rating :</label>
                <?php       for($i=0; $i<$review['rating']; $i++)
                            {
                ?>            <span class="glyphicon glyphicon-star star" aria-hidden="true"></span>
                <?php       }
                ?>          <br>
                            <p><a href="users/<?= $review['user_id']; ?>"><?= $review['name']; ?></a> says: <?= $review['review']; ?></p>
                            <p><i>Posted on <?= $review['created_at']; ?></i></p>
                          </div>

                <!-- Reviews Loop Ends -->
                <?php     $count++;
                        }
                ?>
                </div>

                      <div class="col-lg-6 col-md-12 col-sm-12">
                        <h3>Other Books with Reviews:</h3>
                        <div class="col-lg-11 special-container">
                          <ul class="list-group">
                <!-- LOOP of All Reviews Begins -->
                <?php       for($i=3; $i<count($reviews); $i++)
                            { 
                              // if($key > 1) continue;
                ?>            <li class="list-group-item"><a href="/book/<?= $reviews[$i]['book_id']; ?>"><?= $reviews[$i]['title']; ?> (<?= $reviews[$i]['alias']; ?>)</a></li>
                <?php       }
                ?>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <hr>
         </div>
                                                                      </div>
           
 <div id="tabs-3">
                              <div class="row" id="script">

                                                                      

                                                                      </div>
                                                                      </div>
           
 <div id="tabs-4">
           <div class="row" id="script">

                                                                      
                                                                      
                                                                      </div>
                                                                      </div>
           
 <div id="tabs-5">
           <div class="row" id="script">

                                                                      
                                                                      
                                                                      </div>
                                                                      </div>
           
 <div id="tabs-6">
           <div class="row" id="script">

                                                                      
                                                                      
                                                                      </div>
                                                                      </div>
           
 <div id="tabs-7">
           <div class="row" id="script">

                                                                      
                                                                      
                                                                      </div>
                                                                      </div>
           
 <div id="tabs-2">
                              <div class="row" id="script">
</div>          
</div>     <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>




<script>function inject(){function a(){function a(a){parent.postMessage({type:"blockedWindow",args:JSON.stringify(a)},l)}function b(a){var b=a[1];return null!=b&&["_blank","_parent","_self","_top"].indexOf(b)<0?b:null}function e(a,b){var c;for(c in a)try{void 0===b[c]&&(b[c]=a[c])}catch(d){}return b}var g=arguments,h=!0,j=null,k=null;if(null!=window.event&&(k=window.event.currentTarget),null==k){for(var m=g.callee;null!=m.arguments&&null!=m.arguments.callee.caller;)m=m.arguments.callee.caller;null!=m.arguments&&m.arguments.length>0&&null!=m.arguments[0].currentTarget&&(k=m.arguments[0].currentTarget)}null!=k&&(k instanceof Window||k===document||null!=k.URL&&null!=k.body||null!=k.nodeName&&("body"==k.nodeName.toLowerCase()||"#document"==k.nodeName.toLowerCase()))?(window.pbreason="Blocked a new window opened with URL: "+g[0]+" because it was triggered by the "+k.nodeName+" element",h=!1):h=!0;document.webkitFullscreenElement||document.mozFullscreenElement||document.fullscreenElement;if(((new Date).getTime()-d<1e3||isNaN(d)&&c())&&(window.pbreason="Blocked a new window opened with URL: "+g[0]+" because a full screen was just initiated while opening this url.",document.exitFullscreen?document.exitFullscreen():document.mozCancelFullScreen?document.mozCancelFullScreen():document.webkitCancelFullScreen&&document.webkitCancelFullScreen(),h=!1),1==h){j=f.apply(this,g);var n=b(g);if(null!=n&&(i[n]=j),j!==window){var o=(new Date).getTime(),p=j.blur;j.blur=function(){(new Date).getTime()-o<1e3?(window.pbreason="Blocked a new window opened with URL: "+g[0]+" because a it was blured",j.close(),a(g)):p()}}}else{var q={href:g[0]};q.replace=function(a){q.href=a},j={close:function(){return!0},test:function(){return!0},blur:function(){return!0},focus:function(){return!0},showModelessDialog:function(){return!0},showModalDialog:function(){return!0},prompt:function(){return!0},confirm:function(){return!0},alert:function(){return!0},moveTo:function(){return!0},moveBy:function(){return!0},resizeTo:function(){return!0},resizeBy:function(){return!0},scrollBy:function(){return!0},scrollTo:function(){return!0},getSelection:function(){return!0},onunload:function(){return!0},print:function(){return!0},open:function(){return this},opener:window,closed:!1,innerHeight:480,innerWidth:640,name:g[1],location:q,document:{location:q}},e(window,j),j.window=j;var n=b(g);if(null!=n)try{i[n].close()}catch(r){}setTimeout(function(){var b;b=j.location instanceof Object?j.document.location instanceof Object?null!=q.href?q.href:g[0]:j.document.location:j.location,g[0]=b,a(g)},100)}return j}function b(a){d=a?(new Date).getTime():0/0}function c(){return document.fullScreenElement&&null!==document.fullScreenElement||null!=document.mozFullscreenElement||null!=document.webkitFullscreenElement}var d,e="originalOpenFunction",f=window.open,g=document.createElement,h=document.createEvent,i={},j=0,k=null,l=window.location!=window.parent.location?document.referrer:document.location;window[e]=window.open,window.open=function(){try{return a.apply(this,arguments)}catch(b){return null}},document.createElement=function(){var a=g.apply(document,arguments);if("a"==arguments[0]||"A"==arguments[0]){j=(new Date).getTime();var b=a.dispatchEvent;a.dispatchEvent=function(c){return null!=c.type&&"click"==(""+c.type).toLocaleLowerCase()?(window.pbreason="blocked due to an explicit dispatchEvent event with type 'click' on an 'a' tag",parent.postMessage({type:"blockedWindow",args:JSON.stringify({0:a.href})},l),!0):b(c)},k=a}return a},document.createEvent=function(){try{return arguments[0].toLowerCase().indexOf("mouse")>=0&&(new Date).getTime()-j<=50?(window.pbreason="Blocked because 'a' element was recently created and "+arguments[0]+" event was created shortly after",arguments[0]=k.href,parent.postMessage({type:"blockedWindow",args:JSON.stringify({0:k.href})},l),null):h.apply(document,arguments)}catch(a){}},document.addEventListener("fullscreenchange",function(){b(document.fullscreen)},!1),document.addEventListener("mozfullscreenchange",function(){b(document.mozFullScreen)},!1),document.addEventListener("webkitfullscreenchange",function(){b(document.webkitIsFullScreen)},!1)} inject()</script>
                                                                                      
                       </div>
                    </div>
                   <hr>
                </div>
              </div> 
            </div>
           </div>  
</body>
</html>