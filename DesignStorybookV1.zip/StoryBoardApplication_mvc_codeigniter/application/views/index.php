<?php 
  $this->load->view('partials/head');
?>
  <title>product home Page</title>
</head>
<body>
<?php 
  $this->load->view('partials/navbar');
  $this->load->view('partials/messages');
?>

<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Datamapper ORM</title>
	<link rel="stylesheet" href="/static/css/bootstrap.min.css" />
	<link rel="stylesheet" href="/static/css/bootstrap-responsive.min.css" />
	<link rel="stylesheet" href="/static/css/style.css" />
	<script type="text/javascript" src="/static/js/jquery-1.7.2.min.js"></script>
	<script type="text/javascript" src="/static/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="/static/js/main.js"></script>
</head>
<body>


  <div class="container">
    <div class="row">
      <div class="col-lg-6 col-md-12 col-sm-12">
        <h3>Create Class</h3>
        <form action="add_product" method="post">
          <div class="form-group">
            <label for="name"> name:</label>
            <input type="text" name="name" class="form-control" id="name" placeholder="name">
          </div>
          <div class="form-group">
            <label for="discription">discription:</label>
            <input type="text" name="discription" class="form-control" id="discription" placeholder="discription">
          </div>
          <div class="form-group">
            <label for="price">price:</label>
            <input type="number" step="0.01" name="discription" class="form-control" id="price"></div>
          
          <input type="hidden" name="manufacturer_id" value="<?= $this->session->userdata('user_id'); ?>">
          <input type="submit" class="btn btn-info pull-right" value="Add class">
        </form>
      </div>
    </div>
  </div>

  <div class="row">
				<h3>Add a Product</h3>
				<div id="message" class="text-error"></div>
				<form action="/main/add_product" method="post" id="add_product" class="form-horizontal span4" >
					<fieldset>
						<div class="control-group">
							<label class="control-label" for="Manufacturer Name">Manufacturer/Brand: </label>
							<div class="controls">
							  	<select name="manufacturer_id">
							  		<option value="0">Select a Brand</option>
<?php 							$manufacturers = new Manufacturer();
								$manufacturers->get();

								foreach($manufacturers as $manufacturer)
								{	?>		
							  		<option value="<?= $manufacturer->id ?>"><?= $manufacturer->name ?></option>
<?php 							} 	?>					  		
							  	</select>
							</div>
						</div>	
						<div class="control-group">
							<label class="control-label" for="Product Name">Product Name: </label>
							<div class="controls">
							  	<input type="text" name="name">
							</div>
						</div>	
						<div class="control-group">
							<label class="control-label" for="Price">Price ($): </label>
							<div class="controls">
							 	<input type="text" name="price">
							</div>
						</div>
						<div class="control-group">
							<label class="control-label" for="Description">Description: </label>
							<div class="controls">
								<textarea name="description" cols="60" rows="4"></textarea>
							</div>
						</div>
						<div class="control-group">
							<div class="controls">
							  <button type="submit" class="btn pull-right">Add</button>
							</div>
						</div>
					</fieldset>
				</form>
			</div>
	
	<div id="wrapper">
		<div id="container" class="container">
			<div class="row">
				<h3>Trader's Store</h3>
				<table class="table table-bordered" id="product_listing">
					<thead>
						<tr>
							<th>Manufacturer</th>
							<th>Product Name</th>
							<th>Price ($)</th>
							<th>Date Added</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
<?php					$products = new Product();
						$products->get();

						foreach($products as $product)
						{	
							$manufacturer = new Manufacturer($product->manufacturer_id);
							?>						
							<tr>
								<td><?= $manufacturer->name ?></td>
								<td><a href="/products/products/<?= $product->id ?>"><?= $product->name ?></a></td>
								<td>$<?= $product->price ?></td>
								<td><?= date_default_timezone_set("America/New_York"); echo date_default_timezone_get();?> <?= $product->created_at ?></td>
								<td>
									<a href="/products/products/<?= $product->id ?>">Edit</a>
									<a href="/products/delete_product/<?= $product->id ?>">Delete</a>
								</td>
							</tr>
<?php					}	?>		
					</tbody>
				</table>
			</div>
			<div class="row">
				<h3>Add a Product</h3>
				<div id="message" class="text-error"></div>
				<form action="/products/add_product" method="post" id="add_product" class="form-horizontal span4" >
					<fieldset>
						<div class="control-group">
							<label class="control-label" for="Manufacturer Name">Manufacturer/Brand: </label>
							<div class="controls">
							  	<select name="manufacturer_id">
							  		<option value="0">Select a Brand</option>
<?php 							$manufacturers = new Manufacturer();
								$manufacturers->get();

								foreach($manufacturers as $manufacturer)
								{	?>		
							  		<option value="<?= $manufacturer->id ?>"><?= $manufacturer->name ?></option>
<?php 							} 	?>					  		
							  	</select>
							</div>
						</div>	
						<div class="control-group">
							<label class="control-label" for="Product Name">Product Name: </label>
							<div class="controls">
							  	<input type="text" name="name">
							</div>
						</div>	
						<div class="control-group">
							<label class="control-label" for="Price">Price ($): </label>
							<div class="controls">
							 	<input type="text" name="price">
							</div>
						</div>
						<div class="control-group">
							<label class="control-label" for="Description">Description: </label>
							<div class="controls">
								<textarea name="description" cols="60" rows="4"></textarea>
							</div>
						</div>
						<div class="control-group">
							<div class="controls">
							  <button type="submit" class="btn pull-right">Add</button>
							</div>
						</div>
					</fieldset>
				</form>
			</div>
		</div>
		<div id="footer"></div>
	</div>
</body>
</html>