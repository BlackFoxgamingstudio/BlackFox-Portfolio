<?php 
  $this->load->view('partials/head');
?>

<?php 
  $this->load->view('partials/navbar');
  $this->load->view('partials/messages');
?>

<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Datamapper ORM</title>
	<link rel="stylesheet" href="/static/css/bootstrap.min.css" />
	<link rel="stylesheet" href="/static/css/bootstrap-responsive.min.css" />
	<link rel="stylesheet" href="/static/css/style.css" />
	<script type="text/javascript" src="/static/js/jquery-1.7.2.min.js"></script>
	<script type="text/javascript" src="/static/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="/static/js/main.js"></script>
</head>
<body>
	<div id="wrapper">
		<div id="container" class="container">
			<a href="/products" id="product_listing" class="pull-right">Go to Courses Listing</a>
			<div class="row">
				<h3><?= $product->name ?></h3>
				<div id="message"></div>
				<form action="/product/update_product" method="post" id="update_product" class="form-horizontal span4" >
					<input type="hidden" name="course_id" value="<?= $product->id ?>">
					<fieldset>
						<div class="control-group">
							<label class="control-label" for="Manufacturer Name">Manufacturer/Brand: </label>
							<div class="controls">
							  	<select name="manufacturer_id">
							  		<option value="0">Select a Brand</option>
<?php 							$manufacturers = new Manufacturer();
								$manufacturers->get();

								foreach($manufacturers as $manufacturer)
								{	?>		
							  		<option value="<?= $manufacturer->id ?>" <?= ($manufacturer->id == $product->manufacturer_id) ? 'selected="selected"' : '' ?>><?= $manufacturer->name ?></option>
<?php 							} 	?>					  		
							  	</select>
							</div>
						</div>	
						<div class="control-group">
							<label class="control-label" for="Product Name">Product Name: </label>
							<div class="controls">
							  	<input type="text" name="name" value="<?= $product->name ?>">
							</div>
						</div>	
						<div class="control-group">
							<label class="control-label" for="Price">Price ($): </label>
							<div class="controls">
							 	<input type="text" name="price" value="<?= $product->price ?>">
							</div>
						</div>
						<div class="control-group">
							<label class="control-label" for="Description">Description: </label>
							<div class="controls">
								<textarea name="description" cols="60" rows="4"><?= $product->description ?></textarea>
							</div>
						</div>
						<div class="control-group">
							<div class="controls">
							 	<a href="/products/delete_product/<?= $product->id ?>" class="btn pull-right">Delete</a>
							  	<button type="submit" class="btn pull-right">Update</button>
							</div>
						</div>
					</fieldset>
				</form>
			</div>
		</div>
		<div id="footer"></div>
	</div>
</body>
</html>