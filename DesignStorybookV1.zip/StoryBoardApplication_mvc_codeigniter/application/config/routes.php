<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$route['default_controller'] = "books";
$route['add'] = "/books/add";
$route['add_product'] = "/books/products/add_product";
$route['courses'] = "/courses";
$route['addcourses'] = "/courses/index2";
$route['users/(:num)'] = "/books/users/$1";
$route['book/(:num)'] = "/books/book/$1";
$route['reviews'] = "/books/reviews";
$route['products/(:num)'] = "/books/courses/products/$1";
$route['createNewUser'] = "/books/createNewUser";
$route['createReview'] = "/books/createReview";
$route['book/addReview'] = "/books/addReview";
$route['destroyReview/(:num)'] = "/books/destroyReview/$1";
$route['products'] = "/books/products";
$route['signIn'] = "/books/signIn";
$route['logout'] = "/books/logout";
$route['404_override'] = '';

//end of routes.php