<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Products extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
	}
	
	public function index()
	{
		redirect(base_url('/products'));
	}	

	public function products($product_id = NULL)
	{
		if($product_id == NULL)
			$this->load->view('index');
		else
		{
			$view_data['product'] = new Product($product_id);

			$this->load->view('edit_product', $view_data);
		}
	}	

	public function add_product()
	{
		$data = $this->input->post();

		$product = new Product();

		if(! empty($data['manufacturer_id']))
		{
			if($product->p_save($data))
			{
				$manufacturer = new Manufacturer($product->manufacturer_id);
				$data['id'] = $this->db->insert_id();
				$data['manufacturer_name'] = $manufacturer->name;
				$data['created_at'] = date('F d Y', strtotime($product->created_at));
				$data['status'] = TRUE;
			}
			else
			{
				$data['status'] = FALSE;
				$data['error_message'] = "There was an error in saving your product!";
			}
		}
		else
		{
			$data['status'] = FALSE;
			$data['error_message'] = "You must enter a brand!";
		}

		echo json_encode($data);
	}

	public function update_product()
	{
		$post_data = $this->input->post();

		$data = elements(array('manufacturer_id', 'name', 'price', 'description'), $post_data, NULL);

		$product = new Product();
		$product->where('id', $post_data['product_id'])->update($data);

		if($product->db->affected_rows())
			$data['status'] = TRUE;
		else
		{
			$data['status'] = FALSE;
			$data['error_message'] = "You must enter a brand!";
		}

		echo json_encode($data);
	}

	public function delete_product($product_id = NULL)
	{
		$product = new Product($product_id);
		$product->delete();

		$data['status'] = TRUE;

		redirect(base_url('/products'));
	}	
}