$(document).ready(function(){
	$('#add_product').on('submit', function(){	
		var form = $(this);
		var fields = form.find('input[type=text], textarea, select');
		var error_count = 0; 

		$('#message').html('');

		fields.each(function() {
			var label = $(this).parents('.controls').siblings('label').attr('for');
			
			if($(this).attr('name') == 'manufacturer_id' && $(this).val() == 0)
			{
				$('#message').append('<p>You should pick a '+ label +'.</p>');				
				error_count++;
			}	
			else if($(this).attr('name') == 'name' && $(this).val().length < 8)
			{
				$('#message').append('<p>'+ label +' should be at least 8 characters.</p>');
				error_count++;
			}
			else if($(this).attr('name') == 'price' && (parseInt($(this).val()) <= 0 || isNaN(parseInt($(this).val()))))
			{
				$('#message').append('<p>'+ label +' should be more than $0.</p>');
				error_count++;
			}
			else if($(this).attr('name') == 'description' && $(this).val() == '')
			{
				$('#message').append('<p>'+ label +' should not be empty.</p>');
				error_count++;
			}
			else if($(this).attr('name') == 'description' && $(this).val().length > 50)
			{
				$('#message').append('<p>'+ label +' should not be more than 50 characters.</p>');
				error_count++;
			}
		});

		if(error_count == 0)
		{
			$.post(form.attr('action'),form.serialize(),
				function(data)
				{
					if(data.status)
					{
						$('#product_listing').find('tbody').append('<tr> \
							<td>'+ data.manufacturer_name +'</td> \
							<td>'+ data.name +'</td> \
							<td>$'+ data.price +'</td> \
							<td>'+ data.created_at +'</td> \
							<td> \
								<a href="/main/products/'+ data.id +'">Edit</a> \
								<a href="/main/delete_product/'+ data.id +'">Delete</a> \
							</td> \
						</tr>');
					}
				},
				"json"
			);
		}
		return false;
	});

	$('#update_product').on('submit', function(){	
		var form = $(this);
		var fields = form.find('input[type=text], textarea, select');
		var error_count = 0; 

		$('#message').html('');

		fields.each(function() {
			var label = $(this).parents('.controls').siblings('label').attr('for');
			
			if($(this).attr('name') == 'manufacturer_id' && $(this).val() == 0)
			{
				$('#message').append('<p>You should pick a '+ label +'.</p>');				
				error_count++;
			}	
			else if($(this).attr('name') == 'name' && $(this).val().length < 8)
			{
				$('#message').append('<p>'+ label +' should be at least 8 characters.</p>');
				error_count++;
			}
			else if($(this).attr('name') == 'price' && (parseFloat($(this).val()) <= 0 || isNaN(parseFloat($(this).val()))))
			{
				$('#message').append('<p>'+ label +' should be more than $0.</p>');
				error_count++;
			}
			else if($(this).attr('name') == 'description' && $(this).val() == '')
			{
				$('#message').append('<p>'+ label +' should not be empty.</p>');
				error_count++;
			}
			else if($(this).attr('name') == 'description' && $(this).val().length > 50)
			{
				$('#message').append('<p>'+ label +' should not be more than 50 characters.</p>');
				error_count++;
			}
		});

		if(error_count == 0)
		{
			$.post(form.attr('action'),form.serialize(),
				function(data)
				{
					if(data.status) 
						$('#message').removeClass('text-error').addClass('text-success').html('<p>Updated the product.</p>');
				},
				"json"
			);
		}
		else
		{
			$('#message').removeClass('text-success').addClass('text-error');
		}

		return false;
	});	
});