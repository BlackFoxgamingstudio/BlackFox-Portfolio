-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema book_review
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema book_review
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `book_review` DEFAULT CHARACTER SET utf8 ;
USE `book_review` ;

-- -----------------------------------------------------
-- Table `book_review`.`books`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `book_review`.`books` ;

CREATE TABLE IF NOT EXISTS `book_review`.`books` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `author` VARCHAR(45) NULL DEFAULT NULL,
  `created_at` DATETIME NULL DEFAULT NULL,
  `updated_at` DATETIME NULL DEFAULT NULL,
  `title` VARCHAR(45) NULL DEFAULT NULL,
  `stage` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `book_review`.`courses`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `book_review`.`courses` ;

CREATE TABLE IF NOT EXISTS `book_review`.`courses` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` TEXT NULL DEFAULT NULL,
  `description` LONGTEXT NULL DEFAULT NULL,
  `created_at` DATETIME NULL DEFAULT NULL,
  `updated_on` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 3
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `book_review`.`users`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `book_review`.`users` ;

CREATE TABLE IF NOT EXISTS `book_review`.`users` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NULL DEFAULT NULL,
  `alias` VARCHAR(45) NULL DEFAULT NULL,
  `email` VARCHAR(45) NULL DEFAULT NULL,
  `password` VARCHAR(45) NULL DEFAULT NULL,
  `created_at` DATETIME NULL DEFAULT NULL,
  `updated_at` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `book_review`.`likes`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `book_review`.`likes` ;

CREATE TABLE IF NOT EXISTS `book_review`.`likes` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `created_on` DATETIME NULL DEFAULT NULL,
  `updated_on` DATETIME NULL DEFAULT NULL,
  `likescol` VARCHAR(45) NULL DEFAULT NULL,
  `users_id` INT(11) NOT NULL,
  `books_id` INT(11) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_likes_users1_idx` (`users_id` ASC),
  INDEX `fk_likes_books1_idx` (`books_id` ASC),
  CONSTRAINT `fk_likes_books1`
    FOREIGN KEY (`books_id`)
    REFERENCES `book_review`.`books` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_likes_users1`
    FOREIGN KEY (`users_id`)
    REFERENCES `book_review`.`users` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `book_review`.`likes_copy1`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `book_review`.`likes_copy1` ;

CREATE TABLE IF NOT EXISTS `book_review`.`likes_copy1` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `created_on` DATETIME NULL DEFAULT NULL,
  `updated_on` DATETIME NULL DEFAULT NULL,
  `likescol` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `book_review`.`manufacturers`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `book_review`.`manufacturers` ;

CREATE TABLE IF NOT EXISTS `book_review`.`manufacturers` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(295) NULL DEFAULT NULL,
  `created_at` DATETIME NULL DEFAULT NULL,
  `updated_at` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `book_review`.`products`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `book_review`.`products` ;

CREATE TABLE IF NOT EXISTS `book_review`.`products` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(299) NULL DEFAULT NULL,
  `price` FLOAT NULL DEFAULT NULL,
  `discription` TEXT NULL DEFAULT NULL,
  `created_on` DATETIME NULL DEFAULT NULL,
  `updated_on` DATETIME NULL DEFAULT NULL,
  `manufacturer_id` INT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_products_manufacturers1_idx` (`manufacturer_id` ASC),
  CONSTRAINT `fk_products_manufacturers1`
    FOREIGN KEY (`manufacturer_id`)
    REFERENCES `book_review`.`manufacturers` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 12
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `book_review`.`reviews`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `book_review`.`reviews` ;

CREATE TABLE IF NOT EXISTS `book_review`.`reviews` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `review` VARCHAR(45) NULL DEFAULT NULL,
  `rating` VARCHAR(45) NULL DEFAULT NULL,
  `created_at` DATETIME NULL DEFAULT NULL,
  `updated_at` DATETIME NULL DEFAULT NULL,
  `book_id` INT(11) NOT NULL,
  `user_id` INT(11) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_reviews_books_idx` (`book_id` ASC),
  INDEX `fk_reviews_users1_idx` (`user_id` ASC),
  CONSTRAINT `fk_reviews_books`
    FOREIGN KEY (`book_id`)
    REFERENCES `book_review`.`books` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_reviews_users1`
    FOREIGN KEY (`user_id`)
    REFERENCES `book_review`.`users` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `book_review`.`reviews_copy1`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `book_review`.`reviews_copy1` ;

CREATE TABLE IF NOT EXISTS `book_review`.`reviews_copy1` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `review` VARCHAR(45) NULL DEFAULT NULL,
  `rating` VARCHAR(45) NULL DEFAULT NULL,
  `created_at` DATETIME NULL DEFAULT NULL,
  `updated_at` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
